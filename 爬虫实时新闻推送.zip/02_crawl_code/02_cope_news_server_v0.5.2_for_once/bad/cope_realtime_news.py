import time
import json
import asyncio
import warnings
warnings.filterwarnings("ignore")
from datetime import datetime
from fastapi import FastAPI, WebSocket, WebSocketDisconnect,websockets
from mainbrainQA_core.core.plugin_base import PluginBase
from mainbrainQA_core.core.state_base import MainGraphState
from custom.workflows import realtime_news_flow_2
from mainbrainQA_core.common.utils import writeJson,show_lg,show_er,show_wn,readConf
from pymongo import MongoClient 
from mainbrainQA_core.common.kafka_utils import KFKConsumer
from mainbrainQA_core.solutions.load_model.model_ollama import model_ollama
from custom.plugin.plugin_realtime_news_2.plugin_thrid import ClassifyNews

class ParsingArguments():
    def __init__(self):
        self.state = MainGraphState()
        self._parsing()
    def _parsing(self):
        wbt_server_params = readConf("configs/websocket_server.conf")
        kafka_params = readConf("configs/kafka.conf")
        mongodb_params = readConf("configs/mongodb.conf")
        wkeys_params = readConf("configs/wkeys.conf")
        self.state.parameters.update({"wbt_server_params":wbt_server_params,
                                 "kafka_params":kafka_params,
                                 "mongodb_params":mongodb_params,
                                  "wkeys_params":wkeys_params})
    def handler(self):
        return self.state



app = FastAPI()

state:MainGraphState = ParsingArguments().handler()
HEARTBEAT_INTERVAL = int(state.parameters["wbt_server_params"]["heartbeat_interval"])          # 客户端应每5秒发送心跳
HEARTBEAT_TIMEOUT = int(state.parameters["wbt_server_params"]["heatbeat_timeout"])             # 超时时间为10秒
SEND_INTERVAL = int(state.parameters["wbt_server_params"]["send_interval"])                    # 服务端每2秒发送一次数据
MAX_IDLE_TIME = int(state.parameters["wbt_server_params"]["max_idle_time"])                    # 总空闲时间限制（心跳+常规消息）




@app.websocket("/new/realtime_news_ws")
async def main(websocket: WebSocket):
    global state
    kafka_params = state.parameters["kafka_params"]
    mongodb_params = state.parameters["mongodb_params"]
    wkeys = state.parameters["wkeys_params"]
    #^ init 
    await websocket.accept()

    mongodb_client = MongoClient(mongodb_params["mongodb_ip"])
    db = mongodb_client[mongodb_params["table_name"]]

    kfk_client = KFKConsumer(kafka_params)
    offsets = kfk_client.partition

    chat = model_ollama().init_custom_model("configs/ollama_classify.key")["chat"]
    classify_news = ClassifyNews(wkeys,chat)

    state.parameters.update({"func":{"mongo_db":db,"classify_news": classify_news,"wbt_server":websocket}})
    send_task = None
    heartbeat_task = None
    show_lg(f"0--  {state}")

     # 启动发送任务
    send_task = asyncio.create_task(send_continuously(websocket))
    # 启动心跳检测任务
    heartbeat_task = asyncio.create_task(monitor_heartbeat(
        websocket, 
        timeout=HEARTBEAT_TIMEOUT,
        check_interval=HEARTBEAT_INTERVAL
    ))
    for kfk_message in kfk_client.consumer:
        time.sleep(0.01)
        show_lg(f"1--  {state}")
        heartbeat_message = await asyncio.wait_for(websocket.receive_text(), timeout=MAX_IDLE_TIME)
        data = json.loads(heartbeat_message)
        if data.get('type') == 'heartbeat':
            show_lg(f"Received heartbeat at {datetime.now()}")
        else:
            show_wn(f"Received message: {data}")
        state.parameters.update({"kfk_message":kfk_message})
        # state = await realtime_news_flow_2().ainvoke(state)
        state = realtime_news_flow_2().invoke(state)
        await websocket.send_json({'status': 'ok'})
        show_lg(f"2--  {state}")
        # try:
        #     show_lg(f"1--  {state}")
        #     heartbeat_message = await asyncio.wait_for(websocket.receive_text(), timeout=MAX_IDLE_TIME)
        #     data = json.loads(heartbeat_message)
        #     if data.get('type') == 'heartbeat':
        #         show_lg(f"Received heartbeat at {datetime.now()}")
        #     else:
        #         show_wn(f"Received message: {data}")
        #     state.parameters.update({"kfk_message":kfk_message})
        #     state = await realtime_news_flow_2().ainvoke(state)
            
        #     await websocket.send_json({'status': 'ok'})
        #     show_lg(f"2--  {state}")
        # except asyncio.TimeoutError:
        #     show_wn("[maingraph  TimeoutError]   Connection timed out due to inactivity")
        #     # await websocket.close()
        #     break
        # except WebSocketDisconnect:
        #     show_wn("[maingraph  WebSocketDisconnect]   Client disconnected abruptly")
        #     break
        # except json.JSONDecodeError:
        #     show_er("[maingraph  JSONDecodeError]   Invalid JSON format")
        #     continue
        # except Exception as e:
        #     show_er(f"[maingraph]   {e}   {state}")
        #     break
        # finally:
        #     # await websocket.close()
        #     # if state.parameters.get("mongo"):
        #     #     state.parameters["mongo"].release()
        #     # if state.parameters.get("kafka"):
        #     #     state.parameters["kafka"].release()
        #     show_wn("websocket close")



    # try:
    #     # 启动发送任务
    #     send_task = asyncio.create_task(send_continuously(websocket))
    #     # 启动心跳检测任务
    #     heartbeat_task = asyncio.create_task(monitor_heartbeat(
    #         websocket, 
    #         timeout=HEARTBEAT_TIMEOUT,
    #         check_interval=HEARTBEAT_INTERVAL
    #     ))
    #     for kfk_message in kfk_client.consumer:
    #         time.sleep(0.01)
    #         try:
    #             show_lg(f"1--  {state}")
    #             heartbeat_message = await asyncio.wait_for(websocket.receive_text(), timeout=MAX_IDLE_TIME)
    #             data = json.loads(heartbeat_message)
    #             if data.get('type') == 'heartbeat':
    #                 show_lg(f"Received heartbeat at {datetime.now()}")
    #             else:
    #                 show_wn(f"Received message: {data}")
    #             state.parameters.update({"kfk_message":kfk_message})
    #             state = await realtime_news_flow_2().ainvoke(state)
                
    #             await websocket.send_json({'status': 'ok'})
    #             show_lg(f"2--  {state}")
    #         except asyncio.TimeoutError:
    #             show_wn("[maingraph  TimeoutError]   Connection timed out due to inactivity")
    #             # await websocket.close()
    #             break
    #         except WebSocketDisconnect:
    #             show_wn("[maingraph  WebSocketDisconnect]   Client disconnected abruptly")
    #             break
    #         except json.JSONDecodeError:
    #             show_er("[maingraph  JSONDecodeError]   Invalid JSON format")
    #             continue
    #         except Exception as e:
    #             show_er(f"[maingraph]   {e}   {state}")
    #             break
    #         finally:
    #             # await websocket.close()
    #             # if state.parameters.get("mongo"):
    #             #     state.parameters["mongo"].release()
    #             # if state.parameters.get("kafka"):
    #             #     state.parameters["kafka"].release()
    #             show_wn("websocket close")
    # finally:
    #     kfk_client.consumer.commit() # !
    #     offsets = kfk_client.consumer.committed(kfk_client.tp)
    #     writeJson("configs/index.json",{"partition":offsets})
    #     # 清理任务
    #     if send_task:
    #         send_task.cancel()
    #     if heartbeat_task:
    #         heartbeat_task.cancel()
    #     mongodb_client.close()
    #     kfk_client.release()
    #     show_lg("Connection closed<<<")




async def send_continuously(websocket: WebSocket):
    try:
        while True:
            # 生成要发送的数据
            data = {'timestamp': datetime.now().isoformat(), 'value': 'server_data'}
            await websocket.send_json(data)
            print(f"Sent data: {data}")
            
            await asyncio.sleep(SEND_INTERVAL)
    except (WebSocketDisconnect, asyncio.CancelledError):
        print("Stopped sending data")

async def monitor_heartbeat(websocket: WebSocket, timeout: int, check_interval: int):
    last_valid_heartbeat = datetime.now()
    
    try:
        while True:
            current_time = datetime.now()
            time_since_last = (current_time - last_valid_heartbeat).total_seconds()
            
            if time_since_last > timeout:
                print("Heartbeat timeout detected")
                await websocket.close()
                break
            
            print(f"Checking heartbeat status... {time_since_last:.1f}s elapsed")
            await asyncio.sleep(check_interval)
    except (WebSocketDisconnect, asyncio.CancelledError):
        print("Stopped heartbeat monitoring")


if __name__ == "__main__":
    # 不好使
    import uvicorn
    uvicorn.run(app, host="120.241.223.8", port=8765)
# uvicorn realtime_news:app --reload --host 0.0.0.0 --port 8765  --max  123