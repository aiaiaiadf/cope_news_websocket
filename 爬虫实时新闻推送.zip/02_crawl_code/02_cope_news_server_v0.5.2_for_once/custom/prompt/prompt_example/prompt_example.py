from core.prompt_base import prompt_base

example_prompt = prompt_base()
example_msg="""
# 角色
...
## 技能
...
"""