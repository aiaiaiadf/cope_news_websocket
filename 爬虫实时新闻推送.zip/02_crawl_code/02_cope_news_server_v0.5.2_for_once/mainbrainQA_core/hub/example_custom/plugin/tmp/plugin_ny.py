from core.plugin_base import PluginBase
from custom.prompt.prompt_ny import ny_msg_1,ny_prompt_1,ny_msg_2,ny_prompt_2,ny_msg_3,ny_prompt_3
from core.model_base import model_base
from common.llm_utils import str2dict
from common.utils import show_lg,now,show_db
from custom.db.hongshu_db import hs_db
from random import choice 
from copy import deepcopy
from configs.run_mode import test

class AnalysisQuery(PluginBase):
    def process(self,state):
        llm =  model_base().init_tongy()["chat"]
        query = "触发检测：大连test_1种植地，作物为红薯，土地湿度为11%，种植面积为10亩。"# input("human: ")
        print("human: ",query)
        ny_prompt_1.set_system_msg(ny_msg_1)
        ny_prompt_1.set_human_msg(query)
        msg = ny_prompt_1.get_messages()
        
        res = llm.invoke(msg).content
        res = str2dict(res)
        state.parameters = deepcopy(res)
        return state


def GetWeather():
    r = choice([1,2])
    if r==1:
        return "晴"
    else:
        return "阵雨"

def GetTemperature():
    r = choice([1,2])
    if r==1:
        return "23摄氏度"
    else:
        return "17摄氏度"


def GetTime():
    r = choice([1,2,3])
    if r==1:
        return "2024-5-10 7:22:00"
    elif r==2:
        return "2024-6-11 10:22:00"
    else:
        return "2024-9-12 21:12:12"

class AnalysisTIme(PluginBase):
    def process(self,state):
        llm =  model_base().init_tongy()["chat"]
        ny_prompt_2.set_system_msg(ny_msg_2)
        query = f"当前时间为{GetTime()},外部数据库为{hs_db}"
        ny_prompt_2.set_human_msg(query)
        msg = ny_prompt_2.get_messages()
        
        res = llm.invoke(msg).content
        res = str2dict(res)
        state.parameters.update(res)
        return state



class Irrigation(PluginBase):
    def process(self,state):
        moisture_diff = 0.5 * (float(state.parameters["standard_soil_moisture_up"]) + float(state.parameters["standard_soil_moisture_down"])) -state.parameters["soil_moisture"]
        if moisture_diff <=0:
            state.parameters.update({"irrigation_amount":0})
            return state
        
        def _M2m3(area):
            a = 0.3  
            b = 666.67 * a
            return b*area
        
        area_m3 = _M2m3(state.parameters["area"])
        soil_density = 1330  # 1000-1500千克/每立方米 1.33
        soil_weight = area_m3*soil_density
        state.parameters.update({"irrigation_amount":round(moisture_diff * soil_weight,2)})

        return state
     

class AnalysisResults(PluginBase):
    def process(self,state):
        llm =  model_base().init_tongy()["chat"]
        query = f"天气为{GetWeather()}，温度为{GetTemperature()}，灌溉面积为{state.parameters['area']}亩，计算出来的灌溉值为{state.parameters['irrigation_amount']}升水，时间为{GetTime()}"
        show_db(query)
        query += "，结合这些数据反馈给我结果"
        ny_prompt_3.set_system_msg(ny_msg_3.format(hs_db))
        ny_prompt_3.set_human_msg(query)
        msg = ny_prompt_3.get_messages()
        res = llm.invoke(msg).content
        state.latest_response = res
        show_db(res)
        show_db("已把结果发送给控制中心")
        return state



