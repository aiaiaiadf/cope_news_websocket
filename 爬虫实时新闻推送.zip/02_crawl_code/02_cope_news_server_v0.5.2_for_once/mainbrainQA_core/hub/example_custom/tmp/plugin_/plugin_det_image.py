from core.plugin_base import PluginBase
from custom.prompt.prompt_det import detimg_msg_1,detimg_prompt_1,detimg_msg_2,detimg_prompt_2
from core.model_base import model_base
from common.llm_utils import str2dict,dropNullValue
from common.utils import show_lg,show_db
from ultralytics import YOLO
from copy import deepcopy


class AnalysisQuery(PluginBase):
    def process(self,state):
        # show_db(">> AnalysisQuery")
        llm =  model_base().init_tongy()["chat"]
        if state.isLoop:
            msg = state.user_input
        else:
            query = input("human: ")
            detimg_prompt_1.set_system_msg(detimg_msg_1)
            detimg_prompt_1.set_human_msg(query)
            msg = detimg_prompt_1.get_messages()
            
        res = llm.invoke(msg).content
        res = str2dict(res)
        b = res.get('path',"")
        if b:
            state.isLoop = True
            state.parameters = deepcopy(res)
        else:
            state.isLoop = False
            state.parameters.update(res)
        return state
    

class DetImageResults(PluginBase):
    def process(self,state):
        # show_db(">> DetImageResults")
        model = YOLO("data/yolo11n.pt")
        res = model.predict(state.parameters['path'], save=True, imgsz=640, conf=0.7)
        labels = []
        for c in res[0].boxes.cls:
            labels.append(res[0].names[int(c)])
        state.parameters.update({"labels":labels,"names":res[0].names,})
        return state
    

class AnalysisResults(PluginBase):
    def process(self,state):
        # show_db(">> AnalysisResults")
        llm =  model_base().init_tongy()["chat"]
        labels = state.parameters["labels"]
        names = state.parameters["names"]
        detimg_prompt_2.set_system_msg(detimg_msg_2.format(labels,names))
        detimg_prompt_2.set_human_msg(state.parameters["des"])
        msg = detimg_prompt_2.get_messages()
        res = llm.invoke(msg).content
        show_db(res)
        state.latest_response = res
        return state

class isContinue(PluginBase):
    def process(self,state):
        # show_db(f"iscontinue>> ")
        query = input("human: ")
        if query.lower() == "q":
            state.isLoop = False
            return state
        else:
            state.parameters['des']=query
            detimg_prompt_1.set_system_msg(detimg_msg_1)
            detimg_prompt_1.set_human_msg(query)
            msg = detimg_prompt_1.get_messages()
            state.user_input = msg
            state.isLoop = True
            return state


def routing(state):
    b = state.isLoop
    if b:
        return 'continue'
    else:
        return "end"