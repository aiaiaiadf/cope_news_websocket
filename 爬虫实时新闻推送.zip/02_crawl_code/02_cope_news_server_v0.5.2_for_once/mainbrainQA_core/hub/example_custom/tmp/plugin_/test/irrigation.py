from core.plugin_base import PluginBase
import numpy as np
import math
import json

"""    
砂土：砂土的容重一般为1.2-1.8克/立方厘米，即每立方米的重量约为1200-1800千克。
壤土：壤土的容重一般为1.1-1.6克/立方厘米，即每立方米的重量约为1100-1600千克。
粘土：粘土的容重一般为1.0-1.5克/立方厘米，即每立方米的重量约为1000-1500千克。

=1.33
"""
class irrigation:
    def __init__(self,crop_type:str,soil_moisture:float,area:float) -> None:
        """_summary_
        Args:
            crop_type (str): 作物种类
            soil_moisture (float): 土壤湿度
            area (float): 土地面积
        Desc:
            1. 把土地面从亩改成平方米;
            2. 计算重量;
            3. 根据土地湿度计算土地含数量;
            4. 根据标准值域，计算出达到标准，需要多少水;
            5. 作差，给出结果。
        """
        
        super().__init__()
        self.crop_args = self._get_args(crop_type)
        self.soil_moisture = soil_moisture
        self.area = area
        self.soil_density = 1330  # 1000-1500千克/每立方米 1.33
    # def _read_json(self):
    #     values_map = dict()
    #     with open('configs/crop__moisture.json', 'r') as js_file:
    #         js_data = json.load(js_file)
    #     for ct in js_data["crop_type"]:
    #         for moistures in js_data["moisture"]:
    #             values_map[ct] = {"standard_soil_moisture_up":moistures[0],"standard_soil_moisture_down":moistures[1]}
    def _get_args(self,crop_type):
        # self.values_map=self._read_json()
        self.values_map= {"berry":{"standard_soil_moisture_up":0.7,"standard_soil_moisture_down":0.58}}
        return self.values_map[crop_type]
    def _M2m3(self):
        # 1330立方米等于60厘米*多少亩？
        a = 0.3  # 30cm == 0.3 m
        # 666.67平方米×0.6米=400立方米
        b = 666.67 * a
        return b*self.area
    # def run(self):
    #     area_m3 = self._M2m3()
    #     soil_weight = area_m3*self.soil_density
    #     water_weight = soil_weight*self.soil_moisture
    #     standard_moisture = 0.5 * soil_weight * (self.crop_args["standard_soil_moisture_up"]+ self.crop_args["standard_soil_moisture_down"])
    #     return standard_moisture - water_weight
    def run(self):
        area_m3 = self._M2m3()
        soil_weight = area_m3*self.soil_density
        moisture_diff = 0.5 * (self.crop_args["standard_soil_moisture_up"]+ self.crop_args["standard_soil_moisture_down"]) -self.soil_moisture
        if moisture_diff <=0:
            return 0
        # print(moisture_diff)
        return round(moisture_diff * soil_weight,2)
        



if __name__ == "__main__":
    crop_type="berry"
    soil_moisture=0.2
    area=2.1
    func = irrigation(crop_type,soil_moisture,area)
    res = func.run()
    print(f"{area}亩{crop_type}，湿度为{soil_moisture},需要{res}升水")
    