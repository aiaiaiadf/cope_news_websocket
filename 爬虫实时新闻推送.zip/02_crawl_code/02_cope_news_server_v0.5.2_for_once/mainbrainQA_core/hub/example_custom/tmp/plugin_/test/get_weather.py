from core.plugin_base import PluginBase
from datetime import datetime

import requests, json


class get_weather(PluginBase):
    def process(self,state):
        url = 'http://t.weather.sojson.com/api/weather/city/'
        city = state.user_input
        with open('configs/city.json', 'rb') as f:
            cities = json.load(f)
        city = cities.get(city)
        response = requests.get(url + city)
        d = response.json()
        num = 1
        while True:
            if(d['status'] == 200):
                formatted_date = f'''{"address": {d["cityInfo"]["parent"], d["cityInfo"]["city"]},
                "time": {d["time"], d["data"]["forecast"][0]["week"]},
                "temperature": [{d["data"]["forecast"][0]["high"], d["data"]["forecast"][0]["low"]}],
                "weather": {d["data"]["forecast"][0]["type"]}}'''
                return {"latest_response": f"{formatted_date}"}
                break
            num+=1
            if num >5:
                return {"latest_response": None}
                break
#         # if(d['status'] == 200):
#         #     print("城市：", d["cityInfo"]["parent"], d["cityInfo"]["city"])
#         #     print("时间：", d["time"], d["data"]["forecast"][0]["week"])
#         #     print("温度：", d["data"]["forecast"][0]["high"], d["data"]["forecast"][0]["low"])
#         #     print("天气：", d["data"]["forecast"][0]["type"])



# if __name__ == "__main__":
#     get_weather("大连")