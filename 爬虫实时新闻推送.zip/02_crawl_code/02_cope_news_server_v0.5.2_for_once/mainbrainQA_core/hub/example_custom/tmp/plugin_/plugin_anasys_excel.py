import pandas as pd
from copy import deepcopy
from core.state_base import MainGraphState
from core.plugin_base import PluginBase
from core.model_base import model_base
from custom.prompt.prompt_xlxs import xlxs_msg_1,xlxs_prompt_1,xlxs_msg_2,xlxs_prompt_2
from common.utils import show_lg,show_db
from common.llm_utils import str2dict

#  表格data/workspace_1.xlsx中，周几有体育课？
# 周三和周四都有体育课。
# 谁请假了
# 一周2节体育课够吗


class AnalysisQuery(PluginBase):
    def process(self,state):
        llm =  model_base().init_tongy()["chat"]
        # show_db(f">>> AnalysisQuery")
        query = input("human: ")
        state.isLoop = True
        xlxs_prompt_1.set_system_msg(xlxs_msg_1)
        xlxs_prompt_1.set_human_msg(query)
        msg = xlxs_prompt_1.get_messages()
        state.user_input = msg
        res = llm.invoke(msg).content
        res = str2dict(res)
        state.parameters = deepcopy(res)
        state.user_input=[]
        return state


class ReadExcel(PluginBase):
    def process(self,state:MainGraphState):
        # show_db(f"ReadExcel>>  ")
        df = pd.ExcelFile(state.parameters["path"])
        sheet_names = df.sheet_names
        all_sheets_data = {}
        for sheet_name in sheet_names:
            data = pd.read_excel(df, sheet_name=sheet_name)
            data = data.to_dict(orient='records')
            all_sheets_data[sheet_name] = data
        state.parameters.update({'xlsx': all_sheets_data})
        return state

class AnalysisResults(PluginBase):
    def process(self,state):
        # show_db(f"AnalysisResults>>")
        llm =  model_base().init_tongy()["chat"]
        xlxs_prompt_2.set_system_msg(xlxs_msg_2.format(state.parameters['xlsx']))
        xlxs_prompt_2.set_human_msg(state.parameters["des"])
        msg = xlxs_prompt_2.get_messages()
        res = llm.invoke(msg).content
        show_db(f"AI: {res}")
        # show_lg("~~~~~~~~~~~~~~~~~~~~")
        state.latest_response = res
        return state


class isContinue(PluginBase):
    def process(self,state):
        # show_db(f"iscontinue>> ")
        query = input("human: ")
        if query.lower() == "q":
            state.isLoop = False
            return state
        else:
            state.parameters['des']=query
            state.isLoop = True
            return state

def routing(state):
    b = state.isLoop
    if b:
        return 'continue'
    else:
        return "end"
    
    
    
