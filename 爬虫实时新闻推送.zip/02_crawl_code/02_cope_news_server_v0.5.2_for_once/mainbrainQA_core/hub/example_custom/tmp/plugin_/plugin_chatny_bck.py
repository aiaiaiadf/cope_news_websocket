import pandas as pd
from copy import deepcopy
from core.state_base import MainGraphState
from core.plugin_base import PluginBase
from core.model_base import model_base
from custom.prompt.prompt_chat import chatny_msg_1,chatny_prompt_1,chatny_msg_2,chatny_prompt_2,chatny_msg_3,chatny_prompt_3
from common.utils import show_lg,show_db
from common.llm_utils import str2dict
from common.utils import dictDotNotation
from custom.db.chrom_vector import chromVector
"""


AnalysisQuery,RAGsummarize,AnalysisResults,isContinue,ChooseRAG,Chatsummarize,routing
"""
params = dict(data = "data/db",
                chunk_sz = 200,
                chunk_op = 40)

db_params = dictDotNotation(params)
corp_map = {
        "大白菜":"dabaicai",
        "大豆":"dadou",
        "红薯":"hongshu",
        "黄瓜":"huanggua",
        "棉花":"mianhua",
        "小麦":"xiaomai",
        "西红柿":"xihongshi",
        "芸豆":"yundou",
        "玉米":"yumi",
        "冬小麦":"WinterWheat"
}
# class hello(PluginBase):
#     def process(self,state):
#         answer = "你好，我叫小琪，是你的农业助手"
#         show_db(answer)
#         # state.messages += [{'human':"",'ai':answer}]
#         # return state
#         return {'messages':  [{'human':"",'ai':answer}]}
    
def duplicate_removal(messages:list[dict[str,any]]):
    tmp_lst =[]
    for msg in messages:
        tmp_dct = dict()
        for k,v in list(msg.items()):
            tmp_dct[k] = v.replace(" ","")
        if tmp_dct not in tmp_lst:
            tmp_lst.append(tmp_dct)
    return tmp_lst



def LoadRAG():
    show_db("load rag...")
    embed =  model_base().init_qfan()["embed"]
    db_store = chromVector(db_params)
    db_store._set_embed(embed)
    rag_db = db_store.loopVectorFromDb()
    # rag_db = ""
    return rag_db

rag_db = LoadRAG()


class AnalysisQuery(PluginBase):
    def process(self,state):
        # show_db("AnalysisQuery")
        llm =  model_base().init_tongy()["chat"]
        if state.isLoop:
            msg = state.user_input
        else:
            query = input("human: ")
            state.parameters = deepcopy({"query":query})
            chatny_prompt_1.set_system_msg(chatny_msg_1)
            chatny_prompt_1.set_human_msg(query)
            msg = chatny_prompt_1.get_messages()
        
        state.isLoop = True
        res = llm.invoke(msg).content
        res = str2dict(res)
        if res['crop']:
            res['crop'] = corp_map[res['crop']]
        res_dct = dict()
        for k,v in list(res.items()):
            if v != "":
                res_dct[k] = v
        state.parameters.update(res_dct)
        print(">>  ",state.messages)
        return state

    
class ChooseRAG(PluginBase):
    def process(self,state:MainGraphState):
        show_db(f">>> ChooseRAG  ")
        query = state.parameters["des"]
        crop = state.parameters["crop"]
        rag_info = rag_db[crop].similarity_search(query,k=3)
        state.parameters.update({'rag_info': rag_info})
        print(">>  ",state.messages)
        return state
    
class AnalysisResults(PluginBase):
    def process(self,state:MainGraphState):
        show_db(f">>> AnalysisResults ")
        b = state.parameters.get("rag_info","")
        print(">>  ",state.messages)
        if not b:
            rag_info=""
            chatny_prompt_2.set_system_msg(chatny_msg_2.format("",state.messages,state.summarize))
        else:   
            rag_info = state.parameters["rag_info"]
            chatny_prompt_2.set_system_msg(chatny_msg_2.format(rag_info,"",""))
        query = state.parameters["query"]
        
        llm = model_base().init_tongy()["chat"]
   
        # chatny_prompt_2.set_system_msg(chatny_msg_2.format(rag_info,state.messages,state.summarize))
        chatny_prompt_2.set_human_msg(query)
        msg = chatny_prompt_2.get_messages()
        print("msg>>>   ",msg)
        
        res = llm.invoke(msg).content
        print("res>>>   ",res)
        state.messages += [{'human':query,'ai':res}]
        state.latest_response = res
        show_db(res)
        print(">>  ",state.messages)
        return state


class Chatsummarize(PluginBase):
    def process(self,state):
        show_db(f">>> Chatsummarize")
        llm =  model_base().init_tongy()["chat"]
        state.messages = duplicate_removal(state.messages)
        print(">   ",state.messages)
        if len(state.messages) > 4:
            history_msg = state.messages
            state.messages = []# clear()
            chatny_prompt_3.set_system_msg(chatny_msg_3)
            chatny_prompt_3.set_human_msg(history_msg)
            msg = chatny_prompt_3.get_messages()
            res = llm.invoke(msg).content
            state.summarize += res
            print(">>  ",state.messages)
        return state
    
class isContinue(PluginBase):
    def process(self,state):
        show_db(f">>> iscontinue")
        print(">>  ",state.messages)
        query = input("human: ")
        if query.lower() == "q":
            state.isLoop = False
        else:
            state.parameters = deepcopy({"query":query})
            chatny_prompt_1.set_system_msg(chatny_msg_1)
            chatny_prompt_1.set_human_msg(query)
            msg = chatny_prompt_1.get_messages()
            state.user_input = msg
            state.isLoop = True
        return state


def routing(state):
    b = state.isLoop
    if b:
        return 'continue'
    else:
        return "end"
    
    
def routing_1(state):
    b = state.parameters.get("des","")
    if b:
        return 'rag_db'
    else:
        return "history"