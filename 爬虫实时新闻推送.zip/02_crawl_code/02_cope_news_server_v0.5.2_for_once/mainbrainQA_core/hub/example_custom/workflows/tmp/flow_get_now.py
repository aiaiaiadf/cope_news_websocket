from langgraph.graph import END,START,StateGraph

from core.graph_base import SubGraphBase,UserThreadId,CheckpointMemory
from custom.plugin.plugin_chat.plugin_get_now import GetNow


class getnow_workflow(SubGraphBase):
    def setattr(self):
        self.nodes = {"now":GetNow().handler}
        self.config = UserThreadId("now_1")
        self.ckp = CheckpointMemory()
    def __call__(self, builder:StateGraph):
        for k,v in list(self.nodes.items()):
            builder.add_node(k,v)
        builder.add_edge(START,"now")
        builder.add_edge("now",END)
        self.app = builder.compile(checkpointer=self.ckp)
