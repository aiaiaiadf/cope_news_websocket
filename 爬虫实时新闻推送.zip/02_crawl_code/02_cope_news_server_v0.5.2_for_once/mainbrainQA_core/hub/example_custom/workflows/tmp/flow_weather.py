from langgraph.graph import END,START,StateGraph
from core.graph_base import SubGraphBase,UserThreadId,CheckpointMemory
from custom.plugin.plugin_hello_world import HelloWorld
from custom.plugin.plugin_chat.plugin_get_weather import GetWeather



class helloworld_workflow(SubGraphBase):
    def setattr(self):
        self.nodes = {"GetWeather":GetWeather().handler}
        self.config = UserThreadId("GetWeather_1")
        self.ckp = CheckpointMemory()
    def __call__(self, builder:StateGraph):
        for k,v in list(self.nodes.items()):
            builder.add_node(k,v)
        builder.add_edge(START,"GetWeather")
        builder.add_edge("GetWeather",END)
        self.app = builder.compile(checkpointer=self.ckp)


