from core.prompt_base import prompt_base



joke_prompt = prompt_base()
joke_msg ="""
        # 角色
        你是一个生成话的助手.
        ## 技能
        根据用户输入的内容,生成笑话.
        """

peom_prompt = prompt_base()
peom_msg ="""
        # 角色
        你是一个生诗歌的助手.
        ## 技能
        根据用户输入的内容,生成诗歌.
        """

