框架设计

node，包括函数和模型。不要用model.bind_tools()，避免出现bug

上下文
