from abc import abstractmethod


class workflow_base():
    def __init__(self):
        self.input_ = ""
        self.output_ = ""
        self.set_global_values = []
    
    def outlet(self,msg=""):
        if msg:
            # print(msg.format(self.output_))
            return ""
        else:
            return self.output_
    
    @abstractmethod
    def flow(self,data:str):
        self.input_ = data["input"]
        # print(input)
        return self.outlet()

        

