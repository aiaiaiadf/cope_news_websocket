import asyncio
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from typing import Set

app = FastAPI()
nax_n = 100

connected_clients: Set[WebSocket] = set()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    global connected_clients
    if len(connected_clients) > 10:
        return 0
    else:
        await websocket.accept()
        connected_clients.add(websocket)
        try:
            while True:
                try:
                    # 限制最大等待时间，比如30秒没任何消息就超时
                    data = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                    print(f"收到消息: {data}")
                    await broadcast(f"广播: {data}")
                except asyncio.TimeoutError:
                    # 超时，发送一个心跳ping过去
                    try:
                        await websocket.send_text("ping")
                    except Exception:
                        # ping失败说明连接死了
                        break
        except WebSocketDisconnect:
            pass
        finally:
            connected_clients.discard(websocket)
            print("连接断开")

async def broadcast(message: str):
    for conn in list(connected_clients):
        try:
            await conn.send_text(message)
        except Exception:
            connected_clients.discard(conn)