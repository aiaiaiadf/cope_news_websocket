import asyncio
import websockets
import json
import time

async def client():
    uri = "ws://120.241.223.8:8765/ws"
    async with websockets.connect(uri) as ws:
        try:
            while True:
                # 发送心跳
                await ws.send(json.dumps({'type': 'heartbeat'}))
                print("Sent heartbeat")
                
                # 接收服务端数据
                msg = await ws.recv()
                print(f"Received from server: {msg}")
                
                await asyncio.sleep(6)
                
        except websockets.exceptions.ConnectionClosed:
            print("Connection closed by server")

asyncio.run(client())
