from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import asyncio
import json
from datetime import datetime, timedelta
# uvicorn server:app --reload  

app = FastAPI()

# 配置参数
HEARTBEAT_INTERVAL = 5          # 客户端应每5秒发送心跳
HEARTBEAT_TIMEOUT = 10         # 超时时间为10秒
SEND_INTERVAL = 2              # 服务端每2秒发送一次数据
MAX_IDLE_TIME = 15             # 总空闲时间限制（心跳+常规消息）

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    print("Client connected")
    
    # 初始化状态
    # last_received = datetime.now()
    send_task = None
    heartbeat_task = None
    
    try:
        # 启动发送任务
        send_task = asyncio.create_task(send_continuously(websocket))
        # 启动心跳检测任务
        heartbeat_task = asyncio.create_task(monitor_heartbeat(
            websocket, 
            timeout=HEARTBEAT_TIMEOUT,
            check_interval=HEARTBEAT_INTERVAL
        ))
        
        # 监听客户端消息
        while True:
            try:
                message = await asyncio.wait_for(websocket.receive_text(), timeout=MAX_IDLE_TIME)
                data = json.loads(message)
                
                if data.get('type') == 'heartbeat':
                    print(f"Received heartbeat at {datetime.now()}")
                else:
                    print(f"Received message: {data}")
                
                # last_received = datetime.now()
                
                # 回应心跳确认
                await websocket.send_json({'status': 'ok'})
                
            except asyncio.TimeoutError:
                print("Connection timed out due to inactivity")
                await websocket.close()
                break
            except WebSocketDisconnect:
                print("Client disconnected abruptly")
                break
            except json.JSONDecodeError:
                print("Invalid JSON format")
                continue
                
    finally:
        # 清理任务
        if send_task:
            send_task.cancel()
        if heartbeat_task:
            heartbeat_task.cancel()
        print("Connection closed")

async def send_continuously(websocket: WebSocket):
    try:
        while True:
            # 生成要发送的数据
            data = {'timestamp': datetime.now().isoformat(), 'value': 'server_data'}
            await websocket.send_json(data)
            print(f"Sent data: {data}")
            
            await asyncio.sleep(SEND_INTERVAL)
    except (WebSocketDisconnect, asyncio.CancelledError):
        print("Stopped sending data")

async def monitor_heartbeat(websocket: WebSocket, timeout: int, check_interval: int):
    last_valid_heartbeat = datetime.now()
    
    try:
        while True:
            current_time = datetime.now()
            time_since_last = (current_time - last_valid_heartbeat).total_seconds()
            
            if time_since_last > timeout:
                print("Heartbeat timeout detected")
                await websocket.close()
                break
            
            print(f"Checking heartbeat status... {time_since_last:.1f}s elapsed")
            await asyncio.sleep(check_interval)
    except (WebSocketDisconnect, asyncio.CancelledError):
        print("Stopped heartbeat monitoring")
