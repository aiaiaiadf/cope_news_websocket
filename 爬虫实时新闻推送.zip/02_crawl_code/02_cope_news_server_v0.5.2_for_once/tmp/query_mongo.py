from pymongo import MongoClient
from datetime import datetime
client = MongoClient('mongodb://admin:yulue123456@120.241.223.8:27017')

# 选择数据库和集合
db = client['news']  # 替换为你的数据库名称
collection = db['AI']  # 假设数据存储在名为'news'的集合中
collection_names = db.list_collection_names()
print("collection_names   ",collection_names)
# print(collection.read_concern)



def fetch_latest_news():
    """
    从MongoDB集合中获取类别为'news'且日期在2025年4月1日之前的前10条数据。
    """
    # 定义截止日期
    cutoff_date = datetime(2026, 4, 25,15,51,00)
    print(cutoff_date)
    # 构建查询条件
    query = {
        # 'category': 'AI',
        'news.date': {'$lt': cutoff_date}
    }

    # 执行查询，限制返回10条数据，并按日期降序排序
    results = collection.find(query).sort('news.date', -1).limit(4)

    # 处理并输出结果
    for doc in results:
        print(doc)



        
# 调用函数读取数据
if __name__ == "__main__":
    fetch_latest_news()

    # 关闭数据库连接
    client.close()