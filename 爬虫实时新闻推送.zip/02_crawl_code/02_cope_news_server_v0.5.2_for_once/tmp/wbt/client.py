# from websockets.sync.client import connect
# # ok
# def main():
#     # WebSocket 服务器地址（此处使用公共测试服务器）
#     # uri = "ws://120.241.223.8:8765"
#     uri = "ws://localhost:8765/ws11"
#     ws = connect(uri)
#     try:
#         # 建立同步连接
        
#         print("Connected to server")

#         # 发送消息
#         message = "Hello, WebSocket!"
#         print(f"Sending message: {message}")
#         ws.send(message)

#         # 接收响应
#         response = ws.recv()
#         print(f"Received from server: {response}")

#     except Exception as e:
#         print(f"An error occurred: {e}")

#     finally:
#         # 确保关闭连接
#         ws.close()
#         print("Connection closed")

# if __name__ == "__main__":
#     main()



# client.py
import asyncio
import websockets

async def listen():
    uri = "ws://localhost:8765/ws11"
    async with websockets.connect(uri) as websocket:
        print("Connected to server")
        async for message in websocket:
            print(f"Received: {message}")

asyncio.run(listen())