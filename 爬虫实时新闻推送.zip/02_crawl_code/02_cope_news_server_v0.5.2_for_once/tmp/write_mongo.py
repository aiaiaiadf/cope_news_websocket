from pymongo import MongoClient
from datetime import datetime
# 连接到MongoDB服务器
client = MongoClient('mongodb://admin:yulue123456@120.241.223.8:27017')

# 选择数据库和集合
db = client['test_news_classify']  # 替换为你的数据库名称
collection = db['news_3']  # 假设数据存储在名为'news'的集合中
def insert_news(data):
    """
    插入一条新闻数据到MongoDB集合中。

    参数:
    data (dict): 包含新闻信息的字典，必须包含'category'和'date'字段。
    """
    try:
        collection.insert_one(data)
        print("数据插入成功")
    except Exception as e:
        print(f"插入数据时出错: {e}")
# 示例数据
news_data = {
    'title': '示例新闻标题',
    'content': '这是新闻内容。',
    'category': 'news',
    'date': datetime(2025, 3, 15)  # 确保日期在2025年4月1日之前
}


import random

for i in range(10):
    # 插入数据
    j_lst = [random.choice([1,2,-1,-2,0,0]) for _ in range(3)]
    news_data = {
    'title': f'{i}-示例新闻标题',
    'content': f'{i}-这是新闻内容。',
    'category': 'news',
    'date': datetime(2025+j_lst[0], 3+j_lst[1], 15+j_lst[2])  # 确保日期在2025年4月1日之前
}   
    print(news_data)
    insert_news(news_data)
news_data = {
    'title': '示例新闻标题',
    'content': '这是新闻内容。',
    'category': 'news',
    'date': datetime(2025, 3, 15)  # 确保日期在2025年4月1日之前
}
insert_news(news_data)
# 关闭数据库连接
client.close()