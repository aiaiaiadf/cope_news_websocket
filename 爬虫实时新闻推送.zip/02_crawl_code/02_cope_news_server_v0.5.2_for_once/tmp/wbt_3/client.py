import asyncio
import websockets
import time

async def client():
    uri = "ws://120.241.223.8:8765/ws"
    async with websockets.connect(uri) as ws:
        while True:
            try:
                await ws.send("ping")
                print("Sent ping")
                response = await ws.recv()
                print(f"Received: {response}")
            except Exception as e:
                print("Connection closed", e)
                break
            time.sleep(5)  # 每5秒发送心跳

asyncio.run(client())
