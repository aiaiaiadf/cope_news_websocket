from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import uuid
import time
import asyncio

app = FastAPI()

# 存储所有活跃连接的状态
connections = {}

HEARTBEAT_TIMEOUT = 30  # 心跳超时（秒）
GENERAL_TIMEOUT = 60    # 总超时（秒）

async def monitor_connection(connection_id: str):
    await websocket.accept()
    """后台任务，定期检查连接是否超时"""
    while True:
        await asyncio.sleep(1)  # 每秒检查一次
        conn = connections.get(connection_id)
        if not conn:
            break  # 连接已关闭或不存在
        current_time = time.time()
        last_hb = conn['last_heartbeat']
        last_act = conn['last_activity']
        
        # 检查心跳超时
        if current_time - last_hb > HEARTBEAT_TIMEOUT:
            print(f"Heartbeat timeout for {connection_id}")
            await conn['websocket'].close(code=1001, reason="Heartbeat timeout")
            break
        
        # 检查总超时
        if current_time - last_act > GENERAL_TIMEOUT:
            print(f"General timeout for {connection_id}")
            await conn['websocket'].close(code=1001, reason="Connection timeout")
            break

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    # 生成唯一连接ID
    connection_id = str(uuid.uuid4())
    connections[connection_id] = {
        'websocket': websocket,
        'last_heartbeat': time.time(),
        'last_activity': time.time()
    }
    # 启动后台监控任务
    asyncio.create_task(monitor_connection(connection_id))
    
    try:
        while True:
            message = await websocket.receive_text()
            # 更新最后活动时间
            current_time = time.time()
            connections[connection_id]['last_activity'] = current_time
            
            if message == "ping":
                # 处理心跳消息
                await websocket.send_text("pong")
                connections[connection_id]['last_heartbeat'] = current_time
                print(f"Received heartbeat from {connection_id}")
            else:
                # 处理其他消息（示例：回显）
                await websocket.send_text(f"Received: {message}")
                print(f"Message from {connection_id}: {message}")
    except WebSocketDisconnect:
        print(f"Connection {connection_id} disconnected normally")
    finally:
        # 清理连接状态
        if connection_id in connections:
            del connections[connection_id]
            print(f"Removed connection {connection_id} from tracker")
