from pymongo import MongoClient
from datetime import datetime
client = MongoClient('mongodb://admin:yulue123456@120.241.223.8:27017')

# 选择数据库和集合
db = client['test_news_classify']  # 替换为你的数据库名称
# collection = db['news']  # 假设数据存储在名为'news'的集合中
tmp_collection = db["tmp"]
def fetch_latest_news():
    """
    从MongoDB集合中获取类别为'news'且日期在2025年4月1日之前的前10条数据。
    """
    # 定义截止日期
    cutoff_date = datetime(2025, 3, 15)

    # 构建查询条件
    query = {
        'category': 'tmp',
        'date': {'$lt': cutoff_date}
    }
    for collection_name in db.list_collection_names():
        collection = db[collection_name]
        print(f"正在查询集合: {collection_name}")
        tmp_v = collection.find({})
        tmp_collection.insert_many(tmp_v)
#     # 执行查询，限制返回10条数据，并按日期降序排序
    results = tmp_collection.find(query).sort('date', -1).limit(4)
    for doc in results:
        print(doc)
# # 调用函数读取数据
fetch_latest_news()

# 关闭数据库连接
client.close()