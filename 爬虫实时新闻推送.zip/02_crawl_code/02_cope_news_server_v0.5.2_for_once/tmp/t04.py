# from pymongo import MongoClient
# from datetime import datetime

# # 连接到 MongoDB
# client = MongoClient('mongodb://admin:yulue123456@120.241.223.8:27017')

# # 选择数据库
# db = client['test_news_classify']  # 替换为你的数据库名称

# def merge_all_collections_to_cache():
#     """
#     将数据库中的所有集合合并到缓存中（Python 列表）。
#     """
#     # 获取所有集合名称
#     collection_names = db.list_collection_names()

#     # 初始化缓存（列表）
#     cache = []

#     # 遍历所有集合并读取数据
#     for collection_name in collection_names:
#         source_collection = db[collection_name]
#         print(f"正在读取集合: {collection_name}")

#         # 查询源集合中的所有文档
#         cursor = source_collection.find({})

#         # 将文档添加到缓存中
#         for doc in cursor:
#             cache.append(doc)
#         print(f"已读取 {len(cache)} 条记录")
#     cache.fin
#     print("所有集合已成功合并到缓存中")
#     return cache

# # 调用函数并将结果存储到缓存中
# cache = merge_all_collections_to_cache()

# # 打印缓存中的前 5 条记录
# for doc in cache[:5]:
#     print(doc)

# # 关闭数据库连接
# client.close()
from pymongo import MongoClient
from datetime import datetime

# 连接到 MongoDB
client = MongoClient('mongodb://admin:yulue123456@120.241.223.8:27017')

# 选择数据库
db = client['test_news_classify']  # 替换为你的数据库名称

def merge_all_collections_to_cache():
    """
    将数据库中的所有集合合并到缓存中（Python 列表）。
    """
    # 获取所有集合名称
    collection_names = db.list_collection_names()

    # 初始化缓存（列表）
    cache = []

    # 遍历所有集合并读取数据
    for collection_name in collection_names:
        source_collection = db[collection_name]
        print(f"正在读取集合: {collection_name}")

        # 查询源集合中的所有文档
        cursor = source_collection.find({})

        # 将文档添加到缓存中
        for doc in cursor:
            cache.append(doc)
        print(f"已读取 {len(cache)} 条记录")

    print("所有集合已成功合并到缓存中")
    return cache

def query_and_sort_data(cache, target_date, limit=10):
    """
    查询缓存中指定日期之前的数据，并按时间升序排序，返回前 N 条记录。
    """
    # 过滤出日期之前的文档
    filtered_data = [doc for doc in cache if 'date' in doc and isinstance(doc['date'], datetime) and doc['date'] < target_date]

    # 按日期升序排序
    sorted_data = sorted(filtered_data, key=lambda x: x['date'])

    # 返回前 N 条记录
    return sorted_data[:limit]

# 调用函数并将结果存储到缓存中
cache = merge_all_collections_to_cache()

# 定义查询日期
query_date = datetime(2025, 4, 1)

# 查询缓存中 2025-04-01 之前的 10 条数据，并按时间升序排序
result = query_and_sort_data(cache, query_date, limit=10)

# 打印查询结果
for doc in result:
    print(doc)

# 关闭数据库连接
client.close()
