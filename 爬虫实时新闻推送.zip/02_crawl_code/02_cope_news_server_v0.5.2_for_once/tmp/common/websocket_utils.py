import asyncio
from websockets.sync.client import connect
import json
from common.utils import show_lg,show_er,show_db



class WebSocketClient:
    def __init__(self, wst_params, config=None):
        """
        初始化WebSocket客户端
        :param uri: WebSocket服务器的URI
        :param config: 配置参数字典
        """
        self._parser(wst_params)
        self.uri = self.ip+":"+self.port
        self.config = config if config else {}
    def _parser(self,wst_params):
        self.ip = wst_params['uri']
        self.port = wst_params['port']
        self.out_time = wst_params['out_time']
    

    def process(self, data):
        with connect(self.uri) as websocket:
            websocket.send(json.dumps(data))
            # message = websocket.recv()
            # print(f"Received: {message}")
    def relaese(self):
        del self.websocket




