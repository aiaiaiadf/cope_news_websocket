import asyncio

async def producer1(queue):
    for i in range(5):
        await asyncio.sleep(1)
        message = f"Message {i}"
        await queue.put(message)
        print(f"Sent: {message}")
async def producer2(queue):
    for i in range(5):
        await asyncio.sleep(1)
        message = f"Message {i}"
        await queue.put(message)
        print(f"Sent: {message}")

async def consumer(queue):
    while True:
        message = await queue.get()
        print(">>>>   ",message)
        if message == "STOP":
            break
        print(f"Received: {message}")

async def main():
    q = asyncio.Queue()
    producer_task = asyncio.create_task(producer1(q))
    producer_task = asyncio.create_task(producer2(q))
    consumer_task = asyncio.create_task(consumer(q))
    await asyncio.gather(producer_task)
    await q.put("STOP")  # 通知消费者退出
    await q.put("STOP")  # 通知消费者退出
    message = await q.get()
    print(">>>>   ",message)
    await consumer_task
asyncio.run(main())
