from pymongo import MongoClient
from datetime import datetime
from pydantic import BaseModel
import sys
sys.path.append("/home/cheng/about_llm/05_crawl_code/02_cope_news_server_v0.2")
from mainbrainQA_core.common.utils import strptime,readConf
import pprint

mongo_msg = readConf("/home/cheng/about_llm/05_crawl_code/02_cope_news_server_v0.2/configs/mongodb.conf")

class post_msg(BaseModel):
    date:str
    max_num:str
    label:str


def post_more_news(items:post_msg):
    cutoff_date = strptime(items.date)
    max_num = int(items.max_num)
    # results = {"data":"hello world"}
    client = MongoClient(mongo_msg["mongodb_ip"]) 
    db = client[mongo_msg["table_name"]]

    if items.label == "all":
        def merge_all_collections_to_cache():
            collection_names = db.list_collection_names()
            print("collection_names   ",collection_names)
            cache = []
            for collection_name in collection_names:
                source_collection = db[collection_name]
                # print(f"正在读取集合: {collection_name}")
                cursor = source_collection.find({})
                for doc in cursor:
                    cache.append(doc)
            return cache

        def query_and_sort_data(cache, target_date, limit=10):
            filtered_data = [doc for doc in cache if 'date' in doc and isinstance(doc['date'], datetime) and doc['date'] < target_date]
            sorted_data = sorted(filtered_data, key=lambda x: x['date'])
            return sorted_data[:limit]
        cache = merge_all_collections_to_cache()
        query_date = cutoff_date
        results = query_and_sort_data(cache, query_date, limit=max_num)
    else:
        collection = db["sheet_name"]
        query = {'category': items.label,
                 'date': {'$lt': cutoff_date}}
        results = collection.find(query).sort('date', -1).limit(max_num)
        
    client.close()
    return dict(results=results)


if __name__ == "__main__":
    cfg = post_msg(date="2025-3-15_asd_01-12",
    max_num="10",
    label= "all")
    pprint.pprint(post_more_news(cfg))