from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from kafka import KafkaConsumer
import asyncio
import threading
import json

app = FastAPI()

class KafkaConnectionManager:
    def __init__(self):
        self.consumers = {}
        self.lock = threading.Lock()

    async def connect(self, topic: str, websocket: WebSocket):
        """建立新的Kafka消费者并关联到当前WebSocket连接"""
        consumer_id = id(websocket)
        
        # 创建独立消费者（每个连接单独消费）
        consumer = KafkaConsumer(
            topic,
            bootstrap_servers=['localhost:9092'],
            auto_offset_reset='earliest',
            enable_auto_commit=True,
            group_id=None,  # 禁用消费者组
            value_deserializer=lambda x: json.loads(x.decode('utf-8'))
        )
        
        with self.lock:
            self.consumers[consumer_id] = consumer
        
        asyncio.create_task(self.consume_and_send(consumer_id, websocket))

    async def consume_and_send(self, consumer_id: int, websocket: WebSocket):
        """持续消费Kafka消息并发送到WebSocket"""
        try:
            consumer = self.get_consumer(consumer_id)
            while True:
                msg_pack = next(consumer)
                await websocket.send_json(msg_pack.value)
        except WebSocketDisconnect:
            pass  # 正常断连处理
        finally:
            self.cleanup(consumer_id)

    def get_consumer(self, consumer_id: int):
        with self.lock:
            return self.consumers.get(consumer_id)

    def cleanup(self, consumer_id: int):
        """清理指定消费者资源"""
        with self.lock:
            consumer = self.consumers.pop(consumer_id, None)
            if consumer:
                consumer.close()

kafka_manager = KafkaConnectionManager()

@app.websocket("/ws/{topic}")
async def websocket_endpoint(websocket: WebSocket, topic: str):
    """WebSocket端点，接收路径参数作为Kafka主题"""
    await websocket.accept()
    try:
        await kafka_manager.connect(topic, websocket)
        await websocket.wait_closed()
    except Exception as e:
        print(f"Error: {e}")
    finally:
        await websocket.close()
