from fastapi import FastAPI, Path, HTTPException, Body
from pydantic import BaseModel
from enum import Enum
import uvicorn

# clear && uvicorn t01:app --host 120.241.223.8 --port 8000


app = FastAPI()

# 定义允许的方向枚举
class RollDirection(str, Enum):
    up = "up"
    down = "down"

# 定义请求体模型
class RollData(BaseModel):
    value: str  # 示例字段

# 动态路径参数路由
@app.post("/news/roll_{direction}")
async def roll_action(
    direction: RollDirection,  # 从路径提取变量并校验
    data: RollData = Body(...)  # 解析请求体
):
    print(data.value,direction.value)
    print(RollDirection.up.value,RollDirection.down.value)
    if data.value == direction.:
        # 处理向上滚动逻辑
        result = {"status": f"rolled {direction.value}", "data": data.value}
    else:
        # 理论上不会走到这里，因为枚举已限制取值
        raise HTTPException(status_code=400, detail="Invalid direction")
    return result
