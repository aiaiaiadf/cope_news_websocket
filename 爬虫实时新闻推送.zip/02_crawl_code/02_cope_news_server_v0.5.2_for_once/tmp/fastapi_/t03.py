from fastapi import FastAPI, Path, HTTPException, Body
from pydantic import BaseModel
from enum import Enum

app = FastAPI()

# 定义允许的方向枚举
class RollDirection(str, Enum):
    up = "up"
    down = "down"

# 定义请求体模型
class RollData(BaseModel):
    date:str
    max_num:str
    label:str

# 动态路径参数路由
@app.post("/news/roll_{direction}")
async def roll_action(
    direction: RollDirection,  # 从路径提取变量并校验
    data: RollData = Body(...)  # 解析请求体
):
    print(direction)
    if direction == RollDirection.up:
        # 处理向上滚动逻辑
        result = {"status": "rolled up", "data": data}
    elif direction == RollDirection.down:
        # 处理向下滚动逻辑
        result = {"status": "rolled down", "data": data}
    else:
        # 理论上不会走到这里，因为枚举已限制取值
        raise HTTPException(status_code=400, detail="Invalid direction")
    return result
