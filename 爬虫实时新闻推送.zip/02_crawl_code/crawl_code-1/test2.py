import asyncio
import re
from pymongo import MongoClient
from crawl4ai import *
from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
from pytz import timezone
from datetime import datetime

# MongoDB连接配置
client = MongoClient("mongodb://127.0.0.1:27017/")
db = client["crawl"]
collection = db["PANews_data2"]

# 获取当前北京时间的年、月、日和星期
def get_current_beijing_date():
    tz = timezone('Asia/Shanghai')
    now = datetime.now(tz)
    year = now.year
    month = now.month
    day = now.day
    weekday_mapping = {0: "星期一", 1: "星期二", 2: "星期三", 3: "星期四", 4: "星期五", 5: "星期六", 6: "星期日"}
    weekday = weekday_mapping[now.weekday()]
    return year, month, day, weekday

# 格式化日期时间，使用当前北京时间
def format_date(pubtime_str):
    time_text = pubtime_str.replace(":", "-")
    year, month, day, weekday = get_current_beijing_date()
    return f"{year}-{month:02}-{day:02}_{weekday}_{time_text}"

# 从新闻链接中提取网站名称
def extract_webset(src):
    match = re.search(r'www\.([^.]+)\.com', src)
    if match:
        return match.group(1)
    else:
        return "Unknown"

# 解析新闻页面内容
async def parse_news_page(html):
    soup = BeautifulSoup(html, 'html.parser')
    news_data = []

    articles = soup.find_all('div', class_='item')

    if not articles:
        print("No articles found on this page.")
        # return 

    for article in articles:
        title_tag = article.find('a', class_='n-title')
        title = title_tag.text.strip() if title_tag else "No Title"

        content_tag = article.find('p')
        content = content_tag.text.strip() if content_tag else "No Content"

        pubtime_tag = article.find('div', class_='pubtime')
        pubtime = pubtime_tag.text.strip() if pubtime_tag else "00:00"

        news_data.append({
            'date': format_date(pubtime),
            'title': title,
            'content': content,
            # 'webset': extract_webset(title_tag['href'] if title_tag and title_tag.has_attr('href') else ""),
            'webset': "https://www.panewslab.com".split(".")[1],
            'src': f"https://www.panewslab.com{title_tag['href'] if title_tag and title_tag.has_attr('href') else ''}"
        })

    return news_data

# 使用 Playwright 爬取所有页面数据，并存入 MongoDB
async def scrape_all_pages_with_playwright(start_url, max_clicks=20):
    current_page = start_url
    page_number = 1
    click_count = 0

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True) # default false
        context = await browser.new_context()
        page = await context.new_page()

        try:
            await page.goto(current_page, wait_until="domcontentloaded")
        except Exception as e:
            print(f"Error while trying to access {current_page}: {e}")
            return []

        while True:
            print(f"Scraping page {page_number}: {current_page}")
            html = await page.content()

            news_data = await parse_news_page(html)

            if news_data:
                for news in news_data:
                    print(f"Date: {news['date']}, Title: {news['title']}")
                    print(f"Content: {news['content']}")
                    print(f"Webset: {news['webset']}")
                    print(f"Source: {news['src']}\n")

                    # 插入数据到 MongoDB
                    collection.insert_one({
                        'date': news['date'],
                        'title': news['title'],
                        'content': news['content'],
                        'webset': news['webset'],
                        'src': news['src']
                    })
                    print("Inserted into MongoDB.")

            load_more_button = await page.query_selector('a.load-more')
            if load_more_button and click_count < max_clicks:
                print("Clicking 'Load More' button...")
                await load_more_button.click()
                page_number += 1
                click_count += 1

                print("Waiting for new news items...")
                try:
                    await page.wait_for_selector('div.item', timeout=30000)
                    print(f"Loaded more news, moving to page {page_number}")
                except Exception as e:
                    print(f"Error while waiting for new news items: {e}")
                    break

                await page.wait_for_timeout(3000)  # 等待 3 秒后再进行下一次点击
            else:
                print(f"No more pages or reached {max_clicks} clicks.")
                break

        await browser.close()

# 主函数入口
async def main():
    start_url = "https://www.panewslab.com/zh/news/index.html"
    max_clicks = 300  # 修改为更大的数值，确保可以爬取更多页面
    await scrape_all_pages_with_playwright(start_url, max_clicks)

if __name__ == "__main__":
    asyncio.run(main())
