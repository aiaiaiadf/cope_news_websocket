from kafka import KafkaProducer
from common.utils import show_db

class KFKProducer():
    def __init__(self,kfk_params:dict):
        self._parser(kfk_params)
        # bootstrap_servers='localhost:29092'
        show_db(f"{self.ip}:{self.port}")
        self.produce = KafkaProducer(
            bootstrap_servers=f"{self.ip}:{self.port}",
            acks=self.acks)
    def _parser(self,kfk_params):
        self.ip = kfk_params['kafka_ip']
        self.port = kfk_params['port']
        self.acks = kfk_params['acks']
        self.broker = kfk_params['broker']
        self.topic = kfk_params['topic']
        self.partition = int(kfk_params['partition'])
    def process(self,data):
        data_ = str(data).encode()
        show_db(data['webset'].encode())
        self.produce.send(self.broker,key=data['webset'].encode(),value=data_,partition=self.partition)
        self.produce.flush()
    def release(self):
        self.produce.close()