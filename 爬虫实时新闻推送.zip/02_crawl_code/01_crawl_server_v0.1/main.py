import asyncio
from playwright.async_api import async_playwright



from common.utils import show_db,show_lg,readConf
from common.crawl_utils import parse_news_page
from common.kafka_utils import KFKProducer
from common.mongodb_utils import MongodbServer

"""
1. 爬虫
2. 推到kafka中
3. kafka中拿出来，存到db中。
"""



# 使用 Playwright 爬取所有页面数据，并存入 MongoDB
async def scrape_all_pages_with_playwright(crawl_params_dct,kafka_params_dct,mongodb_params_dct):
    max_clicks=  int(crawl_params_dct["max_clicks"])
    current_page = crawl_params_dct["base_url"]+crawl_params_dct["expand"]
    page_number = 1
    click_count = 0

    _name = current_page.split(".")[1]
    kafka_params_dct.update({"topic":_name})

    kfkp = KFKProducer(kafka_params_dct)
    
    mongodb_params_dct.update({"sheet_name":_name})
    ms = MongodbServer(mongodb_params_dct)


    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True) # default false
        context = await browser.new_context()
        page = await context.new_page()

        try:
            await page.goto(current_page, wait_until="domcontentloaded")
        except Exception as e:
            print(f"Error while trying to access {current_page}: {e}")
            return []

        while True:
            print(f"Scraping page {page_number}: {current_page}")
            html = await page.content()

            news_data = await parse_news_page(crawl_params_dct["base_url"],html)

            if news_data:
                for news in news_data:
                    kfkp.process(news)
                    print(f"Date: {news['date']}, Title: {news['title']}")
                    print(f"Content: {news['content']}")
                    print(f"Webset: {news['webset']}")
                    print(f"Source: {news['src']}\n")

                    # 插入数据到 MongoDB
                    ms.process({
                        'date': news['date'],
                        'title': news['title'],
                        'content': news['content'],
                        'webset': news['webset'],
                        'src': news['src']
                    })
                    print("Inserted into MongoDB.")

            load_more_button = await page.query_selector('a.load-more')
            if load_more_button and click_count < max_clicks:
                print("Clicking 'Load More' button...")
                try:
                    await load_more_button.click()
                except Exception as e:
                    show_db(e)
                page_number += 1
                click_count += 1

                print("Waiting for new news items...")
                try:
                    await page.wait_for_selector('div.item', timeout=30000)
                    print(f"Loaded more news, moving to page {page_number}")
                except Exception as e:
                    print(f"Error while waiting for new news items: {e}")
                    break

                await page.wait_for_timeout(3000)  # 等待 3 秒后再进行下一次点击
            else:
                print(f"No more pages or reached {max_clicks} clicks.")
                break
        
        await browser.close()
        kfkp.release()

async def main():
    crawl_params_dct = readConf("configs/crawl.conf")
    show_lg(f"crawl params: {crawl_params_dct}")
    kafka_params_dct = readConf("configs/kafka.conf")
    show_lg(f"crawl params: {kafka_params_dct}")
    mongodb_params_dct = readConf("configs/mongodb.conf")
    show_lg(f"crawl params: {mongodb_params_dct}")
    await scrape_all_pages_with_playwright(crawl_params_dct,kafka_params_dct,mongodb_params_dct)

if __name__ == "__main__":
    asyncio.run(main())