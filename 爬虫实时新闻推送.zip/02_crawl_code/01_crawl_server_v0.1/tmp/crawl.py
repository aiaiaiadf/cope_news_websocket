import asyncio
import re
from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
from pytz import timezone
from datetime import datetime

def get_current_beijing_date():
    tz = timezone('Asia/Shanghai')
    now = datetime.now(tz)
    year = now.year
    month = now.month
    day = now.day
    weekday_mapping = {0: "星期一", 1: "星期二", 2: "星期三", 3: "星期四", 4: "星期五", 5: "星期六", 6: "星期日"}
    weekday = weekday_mapping[now.weekday()]
    return year, month, day, weekday

def format_date(pubtime_str):
    time_text = pubtime_str.replace(":", "-")
    year, month, day, weekday = get_current_beijing_date()
    return f"{year}-{month:02}-{day:02}_{weekday}_{time_text}"

def extract_webset(src):
    match = re.search(r'www\.([^.]+)\.com', src)
    if match:
        return match.group(1)
    else:
        return "Unknown"

async def parse_news_page(html):
    soup = BeautifulSoup(html, 'html.parser')
    news_data = []

    articles = soup.find_all('div', class_='item')

    if not articles:
        print("No articles found on this page.")

    for article in articles:
        title_tag = article.find('a', class_='n-title')
        title = title_tag.text.strip() if title_tag else "No Title"

        content_tag = article.find('p')
        content = content_tag.text.strip() if content_tag else "No Content"

        pubtime_tag = article.find('div', class_='pubtime')
        pubtime = pubtime_tag.text.strip() if pubtime_tag else "00:00"

        news_data.append({
            'date': format_date(pubtime),
            'title': title,
            'content': content,
            'webset': extract_webset(title_tag['href'] if title_tag and title_tag.has_attr('href') else ""),
            'src': f"https://www.panewslab.com{title_tag['href'] if title_tag and title_tag.has_attr('href') else ''}"
        })

    return news_data

async def scrape_all_pages_with_playwright(start_url, max_clicks=30):
    current_page = start_url
    page_number = 1
    click_count = 0

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context()
        page = await context.new_page()

        try:
            await page.goto(current_page, wait_until="domcontentloaded")
        except Exception as e:
            print(f"Error while trying to access {current_page}: {e}")
            return []

        while click_count < max_clicks:
            print(f"Clicking 'Load More' button {click_count + 1}/{max_clicks} times...")
            load_more_button = await page.query_selector('a.load-more')
            if load_more_button:
                await load_more_button.click()
                click_count += 1

                print("Waiting for new news items...")
                try:
                    await page.wait_for_selector('div.item', timeout=30000)
                    print(f"Loaded more news, continuing to page {page_number + 1}")
                    page_number += 1
                except Exception as e:
                    print(f"Error while waiting for new news items: {e}")
                    break

                await page.wait_for_timeout(3000)  
            else:
                print("No more 'Load More' button.")
                break

        print(f"Finished clicking 'Load More' {click_count} times.")

        print("Starting full scrape after loading...")
        html = await page.content()
        news_data = await parse_news_page(html)

        if news_data:
            for news in news_data:
                print(f"Date: {news['date']}, Title: {news['title']}")
                print(f"Content: {news['content']}")
                print(f"Webset: {news['webset']}")
                print(f"Source: {news['src']}\n")

        await browser.close()

# 主函数入口
async def main():
    start_url = "https://www.panewslab.com/zh/news/index.html"
    max_clicks = 5  # 调整需要点击的次数
    await scrape_all_pages_with_playwright(start_url, max_clicks)

if __name__ == "__main__":
    asyncio.run(main())