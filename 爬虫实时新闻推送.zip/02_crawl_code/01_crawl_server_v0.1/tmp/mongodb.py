from pymongo import MongoClient

def fetch_data_from_mongodb():
    client = MongoClient("mongodb://127.0.0.1:27017/")
    
    db = client["crawl"]
    collection = db["PANews_data2"]
    
    documents = collection.find().limit(10)
    
    for doc in documents:
        print(doc)

if __name__ == "__main__":
    fetch_data_from_mongodb()