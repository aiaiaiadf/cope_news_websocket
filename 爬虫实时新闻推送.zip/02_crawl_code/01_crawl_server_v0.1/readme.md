关键字用双引号，值用双引号。值内部如果有双引号，替换成单引号。

```json
{"news":{"title":"今天是个好日子,'花好月圆'"},...}

```

替换值中不合规的符号
```python3
def replace_invalid_chars(filename):
    invalid_chars = '<>:"/\\|?*'
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    return filename


```


