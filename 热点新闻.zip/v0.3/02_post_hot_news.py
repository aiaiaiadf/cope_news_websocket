import json
import uvicorn
import os
from pydantic import BaseModel
from datetime import datetime as dt
import redis
import json
from fastapi import FastAPI, Body,Path,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from mainbrainQA_core.common.utils import show_db,timepstr,readConf,strptime,readJson

# des  获取更多的新闻，支持两个中各，上划和下拉两个post请求

# uvicorn more_news:app --reload
# uvicorn 02_post_hot_news:app --host 120.241.223.8 --port 28088 --reload


# http://120.241.223.8:28088/docs
# {
#     "date":"2025-05-07_09-30",
#     "max_num":"10"
# }

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

class PostData(BaseModel):
    news_classify:str





@app.post("/news/hot_news")
def post_more_news(items: PostData = Body(...)):
    def thrid2five(like_n,mid_n,hate_n):
        N = like_n + mid_n+hate_n
        if N ==0 :
            return 2
        neutral_ratio = mid_n / N
        adjusted_net = (like_n - hate_n) * (1 - neutral_ratio)
        score = adjusted_net / N
        if score > 0.6:
            return 0
        elif 0.2 < score <= 0.6:
            return 1
        elif -0.2 <=score <= 0.2:
            return 2
        elif -0.6 < score < -0.2:
            return 3
        else:
            return 4
    #^ 从redis获取数据
    redis_msg = readConf("configs/redis.conf")
    redis_client = redis.Redis(host=redis_msg["redis_ip"], port=int(redis_msg["port"]), db=int(redis_msg["db"]))
    outs = redis_client.lrange(items.news_classify,0,-1)
    redis_client.close()
    #^ 从共享目录中获取前天结果
    if os.path.exists("share/hot_news_num.json"):
        last_day_news_info = readJson("share/hot_news_num.json")
        tmp_dct = dict(last_day_news_info=last_day_news_info)
    else:
        tmp_dct = dict()
    
    #^ 解析发送
    if outs:
        news = []
        for out in outs:
            out = json.loads(out.decode('utf-8'))
            if out["stance"] in tmp_dct:
                tmp_dct[out["stance"]] +=1
            else:
                tmp_dct[out["stance"]] =1
            news.append(out)
        flg = thrid2five(tmp_dct["active"],tmp_dct["neutrality"],tmp_dct["negative"])
        tmp_dct["flg"] = flg
        tmp_dct["news"] = news
        return {"results":tmp_dct}
    else:
        return {"results":tmp_dct}


# 保存数据的格式     
"""json
{
  "_id": {
    "$oid": "e017958d0eb8426ff13d9d58"
  },
  "label": "DeFi AI ETH NFT ETF Bitcoin",
  "dateScore"{
      "$date": "2025-05-07T10:30:00Z"
    },
  "news": {
    "id": "e017958d0eb8426ff13d9d5",
    "date": {
      "$date": "2025-05-07T10:30:00Z"
    },
    "title": "昨夜今晨重要资讯（5月6日-5月7日）",
    "content": "疑似与Jeffy Yu关联钱包抛售ZEREBRO，转账逾百万美元至开发者地址\n据Lookonchain监测，一个疑似与Jeffy Yu关联的钱包以8,572枚SOL（约127万美元）价格出售了3555万枚$ZEREBRO，随后将其中7,100枚SOL（约106万美元）转入$LLJEFFY开发者钱包“G5sjgj”。\n币安将支持以太坊网络升级及硬分叉，暂停多个EVM链的充提服务\n据Binance公告，币安将于2025年5月7日17:45（北京时间）起，暂停ETH、Arbitrum、Optimism、zkSync Era、Base、Manta、Starknet、Polygon、Metis、Scroll、Cyber、Metal DAO、Celo及Worldcoin网络的代币充提，以支持ETH网络于18:05进行的升级及硬分叉。期间交易不受影响，币安将代为处理技术问题，待网络稳定后恢复充提，不再另行通知。\nBitwise申请NEAR现货ETF，NEAR加入美SEC审查队列\n据Cointelegraph报道，加密资产管理公司Bitwise已向美国证券交易委员会（SEC）提交S-1文件，申请推出跟踪NEAR代币的现货ETF。该基金将由Coinbase Custody托管，目前尚未披露ETF的交易代码、管理费率及上市交易所。Bitwise已于4月28日在特拉华州注册NEAR信托，并计划递交19b-4文件以正式启动审批流程。\n中国央行宣布降息降准\n中国人民银行行长潘功胜在国新办发布会上宣布，降准0.5个百分点，并降低政策利率0.1个百分点。具体为：第一，降低存款准备金率0.5个百分点，预计将向市场提供长期流动性约1万亿元。第二，完善存款准备金制度，阶段性将汽车金融公司、金融租赁公司的存款准备金率，从目前的5%调降至0%。第三，下调政策利率0.1个百分点，即公开市场7天期逆回购操作利率从目前的1.5%调降至1.4%，预计将带动贷款市场报价利率（LPR）同步下行约0.1个百分点。第四，下调结构性货币政策工具利率0.25个百分点，包括：各类专项结构性工具利率、支农支小再贷款利率，均从目前的1.75%降至1.5%；抵押补充贷款（PSL）利率从目前的2.25%降至2%。 此外，央行将下调个人住房公积金贷款利率0.25个百分点，5年期以上首套房利率由2.85%降至2.6%，其他期限的利率同步调整。增加3000亿元科技创新和技术改造再贷款额度，由目前的5000亿元增加至8000亿元，持续支持“两新”政策实施。中国人民银行将设立5000亿元服务消费与养老再贷款，加大消费重点领域低成本资金支持。\nZerebro项目创始人承认伪造死亡退出，加密圈首现“伪死退场”事件\n据Hey Anon创始人披露，Zerebro创始人通过私人信件承认伪造了自杀事件，目的是为彻底退出公众视野，摆脱骚扰与敲诈。他解释称，若公开离场，将导致其项目代币$ZEREBRO与$OPAIUM暴跌，用户恐慌抛售，自己也可能遭遇更严重人身威胁。目前其已停用所有社交账号，计划匿名从事音乐创作，并称并未从中牟利，仅为寻求安全与隐私。\nCoinbase 推出基于 HTTP 的开源支付协议 x402\nCoinbase开发者平台宣布推出全新开源支付协议 x402，旨在激活互联网长期保留未启用的 HTTP 402 状态码“Payment Required”，将其转化为真正的链上支付层，适用于API服务商、内容创作者、上下文协议等新型场景。x402允许服务器请求支付，客户端（包括人类与智能代理）即时响应，支持微支付按次付费，无需繁琐订阅。Coinbase表示，该协议有望简化Web3支付流程，为代理经济与链上服务提供新基础设施，目前x402已开放源码，欢迎开发者参与共建。\n特朗普家族项目WLFI转移超450万美元资产至未知钱包\n据Onchain Lens监测，5小时前，World Liberty Finance（WLFI）向未知钱包地址转移总值约454万美元的加密资产，包括：103,911枚AVAX（价值204万美元）、598万枚SEI（价值118万美元）、758万枚MOVE（价值132万美元），其中MOVE随后被转入Ceffu钱包。\n新罕布什尔州成为全美首个通过“战略比特币储备”立法的州\n据Satoshi Action Fund发布的声明，新罕布什尔州正式签署HB 302法案，成为全美首个通过“战略比特币储备”（Strategic Bitcoin Reserve, SBR）立法的州。该法案授权州财政官可购买比特币或市值超过5000亿美元的数字资产，并设定持仓上限为总储备资金的5%。储备资产须通过美国监管合规的多签机制或交易所产品进行托管，保障透明与安全。该法案将在60天后正式生效。\nStrike推出比特币抵押贷款服务，最低贷款额7.5万美元\n据The Block报道，由Jack Mallers创立的比特币闪电网络支付应用Strike宣布正式推出加密贷款服务“Strike Lending”。该服务面向个人与企业用户，初期仅在美国特定地区开放，后续将拓展至全球。用户可用比特币作为抵押获取现金，无需出售持仓，贷款期限为12个月，金额区间为7.5万美元至200万美元，年利率至少为12%，且无贷款发起费与提前还款费，信用评分不受影响。Strike强调，其贷款由受审查的资本提供方支持，资产在贷款期间将托管于合作机构，平台始终对用户资产承担法律责任。\nDoodles宣布$DOOD将上线Solana并启动13%空投计划\n据Doodles官方公告，$DOOD代币将作为Solana链原生资产发行，并在TGE（代币生成事件）期间空投至符合条件的钱包地址。OG Doodles、Space Doodles、Dooplicators等多类藏品持有者均可获得分配，13%代币将分配给Bonk、Solana Mobile、Helius等合作社区用户。未预注册用户可在TGE后77天内手动领取。官方计划后续将$DOOD桥接至Base链，实现跨链流通。 首批合作社区包括：BonkBot活跃交易员、Bonk奖励前2500钱包、drip.haus活跃创作者与Doodles藏品持有者、Solana Mobile预购者、Vector广播量前2500钱包、Helius前5000质押者、ElizaOS贡献者、“The Pond”NFT持有者（5月6日快照）等。BSC社区（TST、Mubarak、Babydoge等）空投将由各自项目负责发放。针对Solana生态的社区资格检查工具即将上线。\nUSDC Treasury于Solana链增发2.5亿美元USDC\n据Whale Alert监测，北京时间今日凌晨2:51，USDC发行方USDC Treasury于Solana区块链增发2.5亿美元USDC。此外，凌晨4:01，USDC Treasury还在以太坊链上销毁94,524,840枚USDC，对应金额约为94,522,005美元。\nZKsync实现完全EVM等效，开发者可无缝部署以太坊合约\n据ZKsync官方宣布，ZKsync现已实现完全EVM等效（EVM Equivalence），开发者可直接使用Solidity编译生成的EVM字节码在ZKsync链上部署，无需再使用zkSolc、Foundry ZKsync等特制工具。该功能通过协议第27版升级引入，并由治理提案ZIP-9正式批准上线。 EVM字节码将在EraVM之上通过EVM解释器执行，实现无缝兼容Foundry、Hardhat、Remix等主流以太坊开发工具。尽管如此，因运行模式差异，该机制仍存在gas计算方式不同、部分EVM指令（如CALLCODE、SELFDESTRUCT）不被支持、执行费用高于原生EraVM合约等限制。ZKsync建议性能敏感项目仍以EraVM原生开发为优先。该升级将逐步扩展至Elastic Network中的其他ZK链。\nWLFI发起Snapshot提案，计划向$WLFI持有者空投USD1稳定币\n据World Liberty Financial官方公告，其已上线Snapshot提案，拟测试链上空投功能，向所有符合条件的$WLFI持有者发放少量USD1稳定币，以验证空投系统的实际运行效果并回馈早期支持者。该空投将由WLFI公司资助并通过以太坊主网执行，具体发放金额与资格标准将后续公布。目前投票已开启，将于5月14日结束，投票页面显示支持率100%。\nsns.sol公布SNS代币经济学：空投占比40%\nSolana域名服务sns.sol（原Bonfida）宣布即将推出一款新代币SNS，其中40%的代币将分发给早期和新支持者。此外，其还发布该代币的白皮书和代币经济学，目前空投检查页面已上线。 根据其官网，SNS代币总供应量100亿枚，其中空投占比40%，未来排放和社区20%，生态系统增至26.25%，流动性5%，核心贡献值8.75%。\n上市公司KULR Technology增持42枚比特币，总持仓增至716.2枚\n纽约证券交易所上市公司KULR Technology首席执行官兼联合创始人Michael Mo在X平台发文披露，该公司已以94,403美元均价增持42枚比特币，总价值约400万美元。截至目前，其比特币年收益率（YTD）已达到197.5%。截至2025年5月6日，该公司持有716.2枚比特币，购入均价为96,342美元，总价值约6900万美元。\nCoinbase创始人旗下抗衰老公司NewLimit完成1.3亿美元融资，Kleiner Perkins领投\n据《财富》杂志报道，Coinbase创始人兼首席执行官Brian Armstrong联合创立的生物科技公司NewLimit完成1.3亿美元B轮融资，由Kleiner Perkins领投。该公司专注于表观遗传重编程技术，通过AI与单细胞测序技术修复衰老细胞，已在肝脏和免疫系统细胞再生方面取得突破性进展。Armstrong表示，这项技术有望将人类寿命再次实现“翻倍式”增长。 NewLimit利用人工智能将单次细胞测试成本降至几美分，大幅加速研究进程。公司计划未来两年启动非人灵长类动物实验，2028年前后寻求人体临床试验许可。Kleiner Perkins合伙人Ilya Fushman指出，该技术通过规模化基因组学与前沿AI结合，正以行业前所未有的速度推进抗衰老研究。\nSpace and Time空投已开放查询\nSpace and Time在X平台发文宣布空投查询现已上线，“Gigaclaim 0将为符合条件的社区成员提供高达3.75亿枚SXT的领取机会，领取活动将于5月8日开始。”\n上市公司DeFi Development增持82404枚SOL，总持仓突破40万枚\n据CoinDesk报道，纳斯达克上市公司DeFi Development Corporation（原Janover）宣布通过场外交易增持82,404枚SOL，使其总持仓量突破40万枚，按当前143美元计算价值超5700万美元。该公司表示新购入的代币包含锁定期限制，将通过BitGo场外交易平台持有并用于质押生息。\n贝莱德再次购入5613枚BTC，价值约5.295亿美元\n据Lookonchain监测，贝莱德再次购入5,613枚BTC，价值约5.295亿美元，目前其持有的比特币总量已达620,252枚，价值约585.1亿美元。 自4月21日以来，贝莱德已累计购入47,064枚比特币，总价值约44.4亿美元。\n渣打银行：到2028年底BNB币价或将达到2775美元\n据CoinDesk报道，渣打银行资产研究主管Geoff Kendrick在周二发布的一份研究报告中预测，BNB Chain原生代币BNB有望在2028年底达到2,775美元。报告指出，自2021年5月以来，BNB的价格走势与比特币和以太坊组成的未加权投资组合高度吻合，预计这种相关性将持续。Kendrick预计这种关系将持续下去，BNB的价格将从目前的约600美元上涨至2028年底的2775美元。 Kendrick表示，只要币安仍是最大的中心化交易所（CEX）之一，“BNB的价值驱动因素就不太可能很快发生变化”，这意味着该代币有可能成为数字资产的基准。他指出，BNB Chain几乎完全用于去中心化交易所（DEX）、借贷协议和流动性质押，这意味着它是一个“比以太坊和Avalanche等竞争对手更中心化、更‘传统’的智能合约平台”。\nConflux将销毁7600万枚CFX并质押5亿枚CFX\nConflux Network宣布CFX销毁和质押提案已获投票通过，7600万枚CFX将被销毁，5亿枚CFX将被质押，以降低PoS年利率至约13.38%。Conflux基金会将尽快进行销毁，销毁完成后将会在链上共享记录。\nBerachain Boyco空投已开放领取\nBerachain基金会在X平台宣布，Berachain Boyco空投现已开放领取。官方提醒称，大多数预存款保险库奖励和所有存款必须直接从相应的保险库中领取。非 BERA 激励应在每个协议的网站上领取，具体根据其代币生成事件（TGE）/积分计划等进行。据悉，Boyco是一个预发布流动性平台，用户可直接在以太坊将流动性预存于Berachain的DeFi协议。\n狗狗币生态应用开发层DogeOS完成690万美元融资，Polychain Capital领投\n据CoinDesk报道，狗狗币生态应用开发层DogeOS完成690万美元融资，Polychain Capital领投。该项目旨在为开发者提供基于狗狗币区块链的操作系统级工具，支持游戏、AI等消费级应用开发。MyDoge钱包开发团队CEO Jordan Jefferson表示，现有50万钱包用户的需求表明社区对原生狗狗币应用的强烈期待。 此次融资将加速狗狗币从单纯支付代币向多功能生态转型。DogeOS通过简化开发流程，有望推动更多DeFi和娱乐应用集成DOGE支付，提升其实际使用场景。\n上市公司SOL Strategies宣布购入122,524枚SOL\n据官方消息，加拿大证券交易所上市公司SOL Strategies宣布已以148.96美元均价购入122,524枚SOL代币，动用了其最近完成的ATW融资工具中的全部2000万美元初始资金。\nHaedal推出回购计划，旨在将协议收益直接用于奖励veHAEDAL质押者\n据官方消息，Sui生态流动性质押协议Haedal宣布推出回购计划，旨在将协议收益直接用于奖励veHAEDAL质押者。具体运作方式如下：每周Haedal都会将其协议收益的50%（包括流动性质押费用 + HMM费用 + haeVault的净利润）用于从二级市场直接回 HAEDAL代币。HAEDAL将按照veHAEDAL持有者的余额比例分配给他们。（每次回购后，实际奖励将在下一周的veHAEDAL epoch执行。奖励会自动累积，每周可领取且不会过期。veHAEDAL持有者每周可享受更高的奖励，同时还能获得更多未来实用功能和治理权力。\n币安将上市Maple Finance (SYRUP)和Kamino Finance (KMNO)并为其添加种子标签\n据官方公告，币安将于2025年05月06日23:00（东八区时间）上线Maple Finance (SYRUP)和Kamino Finance (KMNO) 并开放以下现货交易对： SYRUP/USDT、SYRUP/USDC、KMNO/USDT、KMNO/USDCSYRUP，KMNO充值通道将于一小时后开放，提现预计于2025年05月07日23:00（东八区时间）开放。\n金融时报：交易者在特朗普夫人梅拉尼娅代币MELANIA上市前买入，获利1亿美元\n据《金融时报》报道，梅拉尼娅·特朗普的MELANIA代币上市首日疑似存在内幕交易，在特朗普于1月19日宣布该代币推出的前三分钟，就有20多个数字钱包购入价值260万美元的代币，随后12小时内抛售81%持仓获利近1亿美元。这些钱包与德州加密企业家Hayden Davis关联项目存在链上关联，但Davis向独立调查记者否认参与获利。据报道，MELANIA背后的组织者通过位于特拉华州的MKT World LLC运营，已提取6470万美元的一级销售额和手续费，这还不包括早期交易者积累的9960万美元。自2021年以来，梅拉尼娅·特朗普曾使用MKT World开展多项业务，但目前尚未明确其具体角色或利润分享结构。梅拉尼娅尚未公开评论该代币的市场活动或治理。 该媒体报道称，类似的钱包模式也出现在LIBRA丑闻中，这表明利用知名人物进行加密货币投机的策略屡见不鲜。尽管存在监管漏洞和链上匿名性，但这一事件表明数字资产中政治品牌的复杂性日益增加，以及快速发展的加密市场中散户参与者面临的挑战。\nIntoTheBlock与Trident合并成立的DeFi项目Sentora完成2500万美元融资\n据CoinDesk报道，DeFi分析平台IntoTheBlock与流动性服务商Trident Digital宣布合并成立Sentora，并完成2500万美元创始轮融资，New Form Capital领投，Ripple、Tribe Capital、UDHC和Joint Effects等参投，Curved Ventures、Flare和Bankai Ventures等战略生态系统投资者也提供了进一步支持。新公司将由Trident联合创始人、前Coinbase风险策略主管Anthony DeMartino执掌，旨在为机构投资者提供涵盖收益策略、合规风控的一站式链上金融服务。 Sentora整合了IntoTheBlock超30亿美元机构级DeFi分析数据与Trident的结构化流动性方案，将开发统一接口解决多链协议交互碎片化问题。CTO Jesus Rodriguez表示，其目标是构建“使DAO、家族办公室等机构能安全接入DeFi的核心基础设施”。\nMeme币TRUMP的创造者迄今已赚取超3.2亿美元的手续费\n据财富杂志报道，Chainalysis数据显示，自今年早些时候Meme币TRUMP推出以来，其创造者已通过手续费获利超3.2亿美元。在特朗普晚宴首次宣布后，该Meme币的交易活动激增，价格也随之上涨。但特朗普家族无需出售任何迷因币就能赚钱。根据其白皮书，TRUMP总供应量10亿枚中20%已流通，其中半数投入去中心化交易所流动性池。特朗普集团关联公司CIC Digital通过每笔交易收取0.3%手续费获利。区块链分析公司Nansen指出，这种模式不依赖币价波动，而是通过交易量持续获取收益。目前仍有80%代币处于锁仓状态，归属特朗普关联公司。 美国民主党人士批评该模式可能成为匿名者不当影响总统的渠道。尽管特朗普在NBC采访中否认关注币价波动，但数据显示特朗普晚宴消息公布当周相关交易手续费达130万美元。",
    "website": "panewslab",
    "src": "https://www.panewslab.com/zh/sqarticledetails/dg6b43zw.html"
  },
  "next": ""
}





"""
if __name__ == "__main__":
    # 设置主机为0.0.0.0，允许外部访问；端口号为8000
    uvicorn.run(app, host="0.0.0.0", port=28088)
    