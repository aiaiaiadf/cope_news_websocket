


from mainbrainQA_core.common.llm_utils import str2dict
from mainbrainQA_core.common.utils import replace_invalid_chars,show_er,show_db_p
from mainbrainQA_core.solutions.load_model.model_ollama import model_ollama
