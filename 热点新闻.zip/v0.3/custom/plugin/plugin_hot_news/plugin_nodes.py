from mainbrainQA_core.core.plugin_base import PluginBase
from mainbrainQA_core.core.state_base import MainGraphState
from mainbrainQA_core.common.utils import writeJson,readJson,show_db,show_lg,readConf,show_er,strptime,show_wn_p,show_db_p
from mainbrainQA_core.solutions.load_model.model_ollama import model_ollama
from custom.plugin.plugin_hot_news.plugin_3rdpart import *

from custom.prompt.prompt_hot_news.prompt_hot_news_skr import hot_news_skr_msg_1,hot_news_skr_prompt_1
from custom.prompt.prompt_hot_news.prompt_hot_news_anasystcontent import (hot_news_anasyscontent_msg_1,hot_news_anasycontent_prompt_1,
                                                                          hot_news_summarys_msg_1,hot_news_summarys_prompt_1)
from custom.prompt.prompt_hot_news.prompt_hot_news_anasystitle import hot_news_anasystitle_prompt_1, hot_news_anasystitle_msg_1,hot_news_anasystitle_prompt_2, hot_news_anasystitle_msg_2

scores_map = {
    "active":1,
    "negative":1,
    "neutrality":1,
    "other":0
}

class AnalysisQuery(PluginBase):
    async def aprocess(self,state:MainGraphState):
        query = state.parameters["news_title"]
        hot_news_skr_prompt_1.set_system_msg(hot_news_skr_msg_1)
        hot_news_skr_prompt_1.set_human_msg(query)
        msg = hot_news_skr_prompt_1.get_messages()

        chat = model_ollama().init_custom_model("configs/ollama_skr.key")["chat"]
        res = chat.invoke(msg).content

        state.parameters.update({"flow_direc":res})
        show_db(state)
        return state

class AnalysisTitle(PluginBase):
    async def aprocess(self,state:MainGraphState):
        stance_map = [
            "active",
            "negative",
            "neutrality"
        ]

        query = state.parameters["news_title"]
        hot_news_anasystitle_prompt_1.set_system_msg(hot_news_anasystitle_msg_1)
        hot_news_anasystitle_prompt_1.set_human_msg(query)
        msg1 = hot_news_anasystitle_prompt_1.get_messages()

        hot_news_anasystitle_prompt_2.set_system_msg(hot_news_anasystitle_msg_2)
        hot_news_anasystitle_prompt_2.set_human_msg(query)
        msg2 = hot_news_anasystitle_prompt_2.get_messages()

        chat = model_ollama().init_custom_model("configs/ollama_anasystitle.key")["chat"]
        res1 = chat.invoke(msg1).content
        # for flg in ["short_term","mid_term","long_term","other"]
        for flg in ["short_term","mid_term"]:
            if flg in res1:
                res2 = chat.invoke(msg2).content
                out = ""
                for st in stance_map:
                    if st in res2:
                        out = st
                        break 
                state.latest_response = {"stance":out}
        show_db(state)
        return state




class AnalysisContent(PluginBase):
    async def aprocess(self,state:MainGraphState):
        query = state.parameters["news_content"]
        hot_news_summarys_prompt_1.set_system_msg(hot_news_summarys_msg_1)
        hot_news_summarys_prompt_1.set_human_msg(query)
        msg = hot_news_summarys_prompt_1.get_messages()


        chat_1 = model_ollama().init_custom_model("configs/ollama_summary.key")["chat"]
        chat_2 = model_ollama().init_custom_model("configs/ollama_anasyssummary.key")["chat"]

        summarys = chat_1.invoke(msg).content
        tmp = 0
        for summary in summarys[:4].split(","):
            hot_news_anasycontent_prompt_1.set_system_msg(hot_news_anasyscontent_msg_1)
            hot_news_anasycontent_prompt_1.set_human_msg(summary)
            msg = hot_news_anasycontent_prompt_1.get_messages()
            res = chat_2.invoke(msg).content
            try:
                tmp += scores_map[res]
            except:
                tmp += 0 
        score = round(tmp/4)
        state.parameters.update({"hot_news_score":score})
        show_db(state)
        return state



class AnalysisResults(PluginBase):
    async def aprocess(self,state:MainGraphState):

        return state
