from langgraph.graph import END,START,StateGraph
from mainbrainQA_core.core.state_base import MainGraphState
from mainbrainQA_core.core.graph_base import MainGraphBase,UserThreadId,CheckpointMemory
from custom.plugin.plugin_hot_news.plugin_nodes import AnalysisQuery,AnalysisTitle,AnalysisContent,AnalysisResults

from mainbrainQA_core.common.utils import show_lg
import uuid


def routing_1(state:MainGraphState):
    return state.parameters["flow_direc"]

class hot_news_flow(MainGraphBase):
    def setattr(self):
        self.nodes = {
            "AnalysisQuery":AnalysisQuery().ahandler,
            "AnalysisTitle":AnalysisTitle().ahandler,
            # "AnalysisContent":AnalysisContent().ahandler,
            "AnalysisResults":AnalysisResults().ahandler
       
        }
                    
        self.config = UserThreadId(str(uuid.uuid5(uuid.NAMESPACE_OID,"hot news")))
        self.ckp = CheckpointMemory()
    def __call__(self, builder:StateGraph):
        for k,v in list(self.nodes.items()):
            builder.add_node(k,v)
            
        builder.add_edge(START,"AnalysisQuery")
        builder.add_conditional_edges("AnalysisQuery",routing_1,{"f":"AnalysisResults",
                                                                 "t":"AnalysisTitle"})
        
        builder.add_edge("AnalysisTitle","AnalysisResults")
        builder.add_edge("AnalysisResults",END)
        self.app = builder.compile()

   
        
        
        
