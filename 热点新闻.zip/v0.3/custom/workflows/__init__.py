# from custom.workflows.realtime_news_flow_1 import realtime_news_flow_1
# from custom.workflows.realtime_news_flow_2 import realtime_news_flow_2
# from custom.workflows.kafaka_to_mongodb_flow import kafaka_to_mongodb_flow
# from custom.workflows.realtime_news_flow_4 import realtime_news_flow_4
from custom.workflows.hot_news_flow import hot_news_flow