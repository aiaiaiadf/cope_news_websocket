# import redis

# def read_data(key):
#     # 连接到Redis服务器
#     r = redis.Redis(host='localhost', port=6379, db=0)
    
#     # 获取数据并处理编码
#     value = r.get(key)
#     if isinstance(value, bytes):
#         return value.decode('utf-8')  # 转换为字符串
#     return value  # 如果键不存在返回None
# print(read_data('example_key'))



import redis
import json

# 连接到Redis服务器
r = redis.Redis(host='localhost', port=6379, db=0)

# 从Redis读取hot_news键的值
raw_data = r.get('hot_news')

if raw_data:
    # 将bytes转换为字符串并解析为Python对象
    data = json.loads(raw_data.decode('utf-8'))
    print("Data retrieved from Redis:")
    print(data)
else:
    print("Key 'hot_news' does not exist in Redis.")
