# import redis

# def update_and_read_redis(key, value, host='localhost', port=6379, db=0):
#     # 连接到Redis服务器
#     r = redis.Redis(host=host, port=port, db=db)
    
#     # 检查键是否存在并进行相应操作
#     if r.exists(key):
#         r.delete(key)
#     else:
#         r.set(key, value)
    
#     # 读取数据并处理编码
#     data = r.get(key)
#     if isinstance(data, bytes):
#         data = data.decode('utf-8')
    
#     print(f"Key '{key}' has value: {data}")

# # # 示例用法
# # update_and_read_redis('example_key', 'example_value')
# import redis

# def update_data(key, value):
#     # 连接到Redis服务器
#     r = redis.Redis(host='localhost', port=6379, db=0)
    
#     # 检查键是否存在并进行相应操作
#     if r.exists(key):
#         r.delete(key)  # 如果存在则删除
#     else:
#         r.set(key, value)  # 如果不存在则设置新值
# update_data('example_key', 'example_value')




import redis
import json
import datetime
# 连接到Redis服务器
r = redis.Redis(host='localhost', port=6379, db=0)

# 要存储的JSON数据（示例）
data = {
    "title": "Breaking News",
    "content": "This is the latest hot news!",
    "timestamp": "2023-10-05T14:48:00Z",
}

# 将Python字典转换为JSON字符串
json_data = json.dumps(data)

# 写入/更新到Redis的hot_news键
r.set('hot_news', json_data)

# !bad
# data = {
#     "title": "Breaking News",
#     "content": "This is the latest hot news!",
#     "timestamp": "2023-10-05T14:48:00Z",
#     "timestamp": datetime.datetime(2023,10,5,14,48)
# }

# r.set('hot_news', data)
print("Data written to Redis successfully.")
