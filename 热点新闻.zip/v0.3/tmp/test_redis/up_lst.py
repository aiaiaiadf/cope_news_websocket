import redis
import json
# 连接 Redis
r = redis.Redis()

# 原始列表
my_list = [{"a":1}, {"b":2}, {"c":3}]

# 使用 Redis 列表命令逐个添加元素
for item in my_list:
    r.rpush("my_list_key", json.dumps(item))
for item in my_list:
    r.rpush("my_list_key", json.dumps(item))
# 读取列表
retrieved_list = r.lrange("my_list_key", 0, -1)
print(type(retrieved_list))
print(retrieved_list)  # 输出: [b'a', b'b', b'c']
for rl in retrieved_list:
    print(json.loads(rl.decode('utf-8')))