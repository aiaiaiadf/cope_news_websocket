# import asyncio
# import websockets
# n = 0
# async def echo(websocket): #, path):
#     global n
#     try:
#         async for message in websocket:
#             if message is not None:
#                 print(f"Received message: {n} - message")
#                 n+=1
#                 await websocket.send(">>> 收到")
#     except websockets.exceptions.ConnectionClosedError as e:
#         print(f"Connection closed with code={e.code}, reason={e.reason}")
#     await websocket.close(code=1000, reason="Normal closure")
# async def main():
#     # server = await websockets.serve(echo, "localhost", 8765)
#     server = await websockets.serve(echo, "120.241.223.8", 8765)
#     # server = await websockets.serve(echo, "0.0.0.0", 8765)
#     await server.wait_closed()

# if __name__ == "__main__":
#     asyncio.run(main())


# from fastapi import FastAPI, WebSocket, WebSocketDisconnect
# import asyncio
# import json
# import uvicorn
# app = FastAPI()

# # 模拟保存到 MongoDB 的函数（未实现）
# def save_to_mongo(data: dict):
#     # 这里应该是 MongoDB 插入逻辑
#     pass
# # uvicorn server:app --reload
# @app.websocket("/ws")
# async def websocket_endpoint(websocket: WebSocket):
#     await websocket.accept()
#     print("Client connected")
    
#     try:
#         while True:
#             # 构造要发送的数据
#             data = {"message": "Server push message", "timestamp": time.time()}
            
#             # 序列化为 JSON 字符串
#             await websocket.send_json(data)
#             print(f"Sent: {data}")
            
#             # 模拟写入 MongoDB
#             save_to_mongo(data)
            
#             # 等待 2 秒再发送下一条
#             await asyncio.sleep(2)
    
#     except WebSocketDisconnect:
#         print("Client disconnected")
    
#     finally:
#         await websocket.close()
#         print("Connection closed")

# if __name__ == "__main__":
#     # 设置主机为0.0.0.0，允许外部访问；端口号为8000
#     uvicorn.run(app, host="0.0.0.0", port=8765)
    
# server.py

# usage : uvicorn server:app --reload --host 0.0.0.0 --port 8765
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import asyncio
import time

app = FastAPI()

# 模拟MongoDB存储函数（未实现）
def save_to_mongo(data: dict):
    """这里应该实现将数据保存到MongoDB的逻辑"""
    pass

@app.websocket("/ws11")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    print(">>>   ",websocket.state)
    print("Client connected")
    
    try:
        while True:
            # 构造要发送的数据包
            message_data = {
                "message": "Server push message",
                "timestamp": time.time()
            }
            
            # 发送JSON格式消息
            await websocket.send_json(message_data)
            print(f"Sent: {message_data}")
            
            # 模拟保存到MongoDB
            save_to_mongo(message_data)
            
            # 每2秒发送一次
            await asyncio.sleep(2)
    
    except WebSocketDisconnect:
        print("Client disconnected")
    
    finally:
        await websocket.close()
        print("Connection closed")

if __name__ == "__main__":
    # 不好使
    import uvicorn
    uvicorn.run(app, host="localhost", port=8765)

