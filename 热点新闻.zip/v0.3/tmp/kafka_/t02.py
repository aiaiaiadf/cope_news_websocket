from kafka import KafkaConsumer, TopicPartition
import sys

def consume_one_message():
    # 配置消费者参数
    consumer = KafkaConsumer(
        enable_auto_commit= False,
        bootstrap_servers='localhost:29092',  # 替换为你的 Kafka 服务器地址
        group_id='432',         # 可选：消费者组 ID
        auto_offset_reset='earliest', # 从最早的偏移量开始消费
    )
    tp = TopicPartition("crawl",0)
    consumer.assign([tp])
    try:
        # # 获取一条消息（非阻塞） # 方法-1
        messages = consumer.poll(timeout_ms=1000, max_records=1)
     
        if not messages:
            print("未收到任何消息")
            return
        
        # 提取第一条消息
        for i,(topic, msgs) in enumerate(messages.items()):
            if msgs:
                message = next(iter(msgs))
                print(f"Received message: {message.value}   {i}   {topic}")
                break
        # # # 获取一条消息（非阻塞） # 方法-2
        # messages = next(consumer)
        # if not messages:
        #     print("未收到任何消息")
        #     return
        # data = messages.value.decode()
        # print(data)
    except Exception as e:
        print(f"发生错误: {e}", file=sys.stderr)
    finally:
        # 关闭消费者连接
        consumer.close()

if __name__ == "__main__":
    consume_one_message()
