import asyncio

# 共享字典
shared_data = {}
lock = asyncio.Lock()

async def update_data(key, value):
    async with lock:
        shared_data[key] = value
        print(f"Updated: {key} -> {value}")

async def read_data(key):
    async with lock:
        value = shared_data.get(key, "Not Found")
        print(f"Read: {key} -> {value}")
        return value

async def main():
    await asyncio.gather(
        update_data("a", 1),
        read_data("c"),
        update_data("b", 2),
        read_data("a"),
        
    )
asyncio.run(main())
