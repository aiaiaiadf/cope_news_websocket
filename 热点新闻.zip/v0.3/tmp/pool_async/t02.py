import asyncio
from concurrent.futures import ThreadPoolExecutor
import time

# 定义一个简单的异步函数
async def async_task(name, duration):
    #! graph
    print(f"Task {name} started (thread: {threading.get_ident()})")
    await asyncio.sleep(duration)
    print(f"Task {name} completed (thread: {threading.get_ident()})")

# 在线程中运行asyncio事件的封装函数
def run_asyncio_task(coro):
    loop = asyncio.new_event_loop()        # 创建新事件循环
    asyncio.set_event_loop(loop)           # 设置为当前线程的默认事件循环
    try:
        loop.run_until_complete(coro)       # 运行协程
    finally:
        loop.close()                        # 关闭事件循环

if __name__ == "__main__":
    import threading
    with ThreadPoolExecutor(max_workers=3) as executor:
        # 提交多个异步任务到线程池
        futures = []
        for i in range(5):
            coro = async_task(f"Task-{i}", 2)
            futures.append(executor.submit(run_asyncio_task, coro))
        
        # 等待所有线程完成
        for future in futures:
            future.result()  # 获取结果（可选）

    print("All tasks completed.")
