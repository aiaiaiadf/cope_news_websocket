import asyncio
import concurrent.futures
async def do_something_blocking():
    # 在线程池中执行阻塞的IO操作
    
    with concurrent.futures.ThreadPoolExecutor(10) as pool:
        
            result = await loop.run_in_executor(pool, blocking_io_operation)
            return result
def blocking_io_operation():
# 执行一些阻塞的IO操作，比如网络请求或者文件读写
    print("hello world ~")

async def main():
    result = await do_something_blocking()
    print(result)
if __name__ == "__main__":
    #创建一个事件循环并运行我们的主函数
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())