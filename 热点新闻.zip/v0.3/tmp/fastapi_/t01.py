from fastapi import FastAPI, Path, HTTPException, Body
from pydantic import BaseModel

app = FastAPI()

# 定义请求体模型
class RollData(BaseModel):
    date: str
    max_num: str
    label: str

# 动态路径参数路由
@app.post("/news/roll_{direction}")
async def roll_action(
    direction: str = Path(..., description="滚动方向"),  # 路径参数改为字符串类型
    data: RollData = Body(...)  # 解析请求体
):
    # 校验方向参数合法性
    if direction not in ["up", "down"]:
        raise HTTPException(status_code=400, detail="Invalid direction")
    
    if direction == "up":
        # 处理向上滚动逻辑
        result = {"status": "rolled up", "data": data}
    elif direction == "down":
        # 处理向下滚动逻辑
        result = {"status": "rolled down", "data": data}
    return result
