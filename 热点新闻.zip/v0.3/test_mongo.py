import sys
sys.path.append(".")
import time
import asyncio
import warnings
warnings.filterwarnings("ignore")
import datetime
from datetime import datetime as dt
from concurrent.futures import ThreadPoolExecutor

from pymongo import MongoClient


from custom.workflows.hot_news_flow import hot_news_flow
from mainbrainQA_core.core.state_base import MainGraphState
from mainbrainQA_core.common.llm_utils import str2dict
from mainbrainQA_core.common.utils import show_lg,show_er,show_wn,show_lg_p,show_er_p,show_db_p,readConf,strptime

def information_within_the_time_interval(collection,start_time,end_time):
    # print(f"正在读取集合: {collection_name}")
    results = collection.find({
        "news.date": {
            "$gte": start_time,
            "$lte": end_time
        }
    }).sort("news.date", 1)
    show_db_p(f"results     {list(results)}")
    return list(results)
    # cache = []
    # show_db_p(f"results     {list(results)}")
    # for result in results:
    #     cache.append(result)
    # show_db_p(f"information_within_the_time_interval    {cache}")
    # return cache

start_time = datetime.datetime(2025,5,7,9,0)
end_time = datetime.datetime(2025,5,7,10,0)
show_db_p(f"start_time:   {start_time}  end_time:   {end_time}")
mongo_msg = readConf("configs/hot_news_mongo.conf")
mongo_client = MongoClient(mongo_msg["mongodb_ip"]) 
retrieve_db = mongo_client[mongo_msg["retrieve_table_name"]]
save_db = mongo_client[mongo_msg["save_table_name"]]
retrieve_collection_names = retrieve_db.list_collection_names()

tmp_lst = []
for collection_name in retrieve_collection_names:
    retrieve_collection = retrieve_db[collection_name]
    show_lg_p(collection_name)
    results = information_within_the_time_interval(retrieve_collection,start_time,end_time)
    tmp_lst.extend(results)