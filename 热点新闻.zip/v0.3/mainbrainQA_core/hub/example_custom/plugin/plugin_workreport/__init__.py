from custom.plugin.plugin_workreport.plugin_edit import edit_xlsx
from custom.plugin.plugin_workreport.plugin_anasys import anasys_workreport
from custom.plugin.plugin_workreport.plugin_reporting import reporting
from custom.plugin.plugin_workreport.plugin_main import AnalysisQuery,routing

