from core.prompt_base import prompt_base
from langchain_core.messages import SystemMessage

class selector_prompt(prompt_base):
    def set_system_msg(self,s1:str=""):
        if s1 == "":
                self.system_msg = SystemMessage(
                content="""
                        # 角色
                        你是一个函数调用助手，根据用户的输入，调用相应的函数。
                        ## 技能
                        技能-1 如果用户输入想获取当前日期，调用tool_c.perform_action()工作流。
                        技能-2 如果用户输入想测试工作流，调用
                        """
                )
        else:
            self.system_msg = SystemMessage(
            content=s1
            )
        if len(self.messages)==2:
            self.messages[:1] += [self.human_msg]
        else:
            self.messages = [self.system_msg,self.human_msg]