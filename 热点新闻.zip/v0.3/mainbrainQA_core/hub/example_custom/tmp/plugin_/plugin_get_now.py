from core.plugin_base import PluginBase
from datetime import datetime
from common.utils import show_db
class GetNow(PluginBase):
    def process(self,state):
        args="%Y-%m-%d %H:%M:%S"
        current_date = datetime.now()
        formatted_date = current_date.strftime(args)
        show_db(formatted_date)
        state.latest_response = formatted_date
        return state
 
   



