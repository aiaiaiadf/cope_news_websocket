from core.plugin_base import PluginBase
from common.utils import show_db
class HelloWorld(PluginBase):
    def process(self,state):
        show_db("hello LLM")
        state.latest_response = "hello LLM"
        return state
    

