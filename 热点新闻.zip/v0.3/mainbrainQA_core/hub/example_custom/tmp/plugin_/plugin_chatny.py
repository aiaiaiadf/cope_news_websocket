import pandas as pd
from copy import deepcopy
from core.state_base import MainGraphState
from core.plugin_base import PluginBase
from core.model_base import model_base
from custom.prompt.prompt_chat import chatny_msg_1,chatny_prompt_1,chatny_msg_2,chatny_prompt_2,chatny_msg_3,chatny_prompt_3
from common.utils import show_lg,show_db
from common.llm_utils import str2dict,duplicate_removal
from common.utils import dictDotNotation
from custom.db.chrom_vector import chromVector

from langgraph.graph import END,START,StateGraph
from core.graph_base import SubGraphBase,UserThreadId,CheckpointMemory


params = dict(data = "data/db",
                chunk_sz = 200,
                chunk_op = 40)

db_params = dictDotNotation(params)
corp_map = {
        "大白菜":"dabaicai",
        "大豆":"dadou",
        "红薯":"hongshu",
        "黄瓜":"huanggua",
        "棉花":"mianhua",
        "小麦":"xiaomai",
        "西红柿":"xihongshi",
        "芸豆":"yundou",
        "玉米":"yumi",
        "冬小麦":"WinterWheat"
}

# class hello(PluginBase):
#     def process(self,state):
#         answer = "你好，我叫小琪，是你的农业助手"
#         show_db(answer)
#         state.messages = deepcopy([{'human':"",'ai':answer}])
#         return state

def LoadRAG():
    show_db("load rag...")
    embed =  model_base().init_qfan()["embed"]
    db_store = chromVector(db_params)
    db_store._set_embed(embed)
    rag_db = db_store.loopVectorFromDb()
    return rag_db

rag_db = ""# LoadRAG()


# class AnalysisQuery(PluginBase):
#     def process(self,state):
#         # show_db("AnalysisQuery")
#         llm =  model_base().init_tongy()["chat"]
#         msg = state.user_input
#         res = llm.invoke(msg).content
#         res = str2dict(res)
#         if res['crop']:
#             res['crop'] = corp_map[res['crop']]
#         res_dct = dict()
#         for k,v in list(res.items()):
#             if v != "":
#                 res_dct[k] = v
#         state.parameters.update(res_dct)
#         return state

class AnalysisQuery(PluginBase):
    def process(self,state):
        # show_db("AnalysisQuery")
        llm =  model_base().init_tongy()["chat"]
        msg = state.user_input
        while True:
            res = llm.invoke(msg).content
            try:
                res = str2dict(res)
                if res['crop']:
                    res['crop'] = corp_map[res['crop']]
                break
            except:
                show_db("没理解你的意思")
                query = input("human: ")
                chatny_prompt_1.set_system_msg(chatny_msg_1)
                chatny_prompt_1.set_human_msg(query)
                msg = chatny_prompt_1.get_messages()
        
        state.user_input = msg        
        
        res_dct = dict()
        for k,v in list(res.items()):
            if v != "":
                res_dct[k] = v
        state.parameters.update(res_dct)
        return state
    
class ChooseRAG(PluginBase):
    def process(self,state:MainGraphState):
        # show_db(f">>> ChooseRAG  ")
        query = state.parameters["des"]
        crop = state.parameters["crop"]
        # print(">>   ",query,crop,rag_db)
        rag_info = rag_db[crop].similarity_search(query,k=3)
        state.parameters.update({'rag_info': rag_info})
        return state
    
class AnalysisResults(PluginBase):
    def process(self,state:MainGraphState):
        # show_db(f">>> AnalysisResults ")
        b = state.parameters.get("rag_info","")
        if not b:
            rag_info=""
        else:
            rag_info = state.parameters["rag_info"]
        chatny_prompt_2.set_system_msg(chatny_msg_2.format(rag_info,state.messages,state.summarize))
        # b = state.parameters.get("rag_info","")
        # if not b:
        #     rag_info=""
        #     chatny_prompt_2.set_system_msg(chatny_msg_2.format("",state.messages,state.summarize))
        # else:
        #     rag_info = state.parameters["rag_info"]
        #     chatny_prompt_2.set_system_msg(chatny_msg_2.format(rag_info,"",""))
        state.parameters["rag_info"] = ""
        query = state.parameters["query"]
        llm = model_base().init_tongy()["chat"]
        chatny_prompt_2.set_human_msg(query)
        msg = chatny_prompt_2.get_messages()
        res = llm.invoke(msg).content
        state.messages += [{'human':query,'ai':res}]
        state.latest_response = res
        show_db(res)
        return state


class Chatsummarize(PluginBase):
    def process(self,state):
        # show_db(f">>> Chatsummarize")
        llm =  model_base().init_tongy()["chat"]
        state.messages = duplicate_removal(state.messages)
        if len(state.messages) > 4:
            history_msg = state.messages
            state.messages = []
            chatny_prompt_3.set_system_msg(chatny_msg_3)
            chatny_prompt_3.set_human_msg(history_msg)
            msg = chatny_prompt_3.get_messages()
            res = llm.invoke(msg).content
            state.summarize += res
        return state
    



class chatny_once(SubGraphBase):
    def setattr(self):
        self.nodes = {
                      "AnalysisQuery":AnalysisQuery().handler,
                      "ChooseRAG":ChooseRAG().handler,
                       "AnalysisResults":AnalysisResults().handler,
                       "Chatsummarize":Chatsummarize().handler,
                      }
        self.config = UserThreadId("ny_1")
        self.ckp = CheckpointMemory()
    def __call__(self, builder:StateGraph):
        builder.recursion_limit =100
        for k,v in list(self.nodes.items()):
            builder.add_node(k,v)
            
        builder.add_edge(START,"AnalysisQuery")
        builder.add_conditional_edges("AnalysisQuery",routing_1,{'rag_db':"ChooseRAG","history":"AnalysisResults"})
        builder.add_edge("ChooseRAG","AnalysisResults")
        builder.add_edge("AnalysisResults","Chatsummarize")
        builder.add_edge("Chatsummarize",END)
        self.app = builder.compile(checkpointer=self.ckp)
    def invoke(self,state:MainGraphState):
        for event in self.app.stream(state, self.config, stream_mode="values"):
            ...
            # print(event)
        return state
        
class chatny(PluginBase):
    def process(self,state):
        bot =chatny_once()
        while True:
            query = input("human: ")
            if query == "q":
                break
            chatny_prompt_1.set_system_msg(chatny_msg_1)
            chatny_prompt_1.set_human_msg(query)
            msg = chatny_prompt_1.get_messages()
            state = MainGraphState(
                user_input=msg,
                parameters={"query":query}
            )
            state = bot.invoke(state)
        return state        


    
def routing_1(state):
    b = state.parameters.get("crop","")
    if b:
        return 'rag_db'
    else:
        return "history"