from core.prompt_base import prompt_base


weather_prompt = prompt_base()
weather_msg="""
# 角色
你是一个语义拆分助手。
## 技能
根据用户的输入内容，把里面的城市名字拆分出来。只要城市名字，不带市、县等信息。
"""



