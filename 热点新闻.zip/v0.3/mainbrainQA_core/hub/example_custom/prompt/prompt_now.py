from core.prompt_base import prompt_base


now_prompt = prompt_base()
now_msg="""
# 角色
你是一个数据查询助手。
## 技能
理解根据用户的输入，从外部知识库中查找到对应的值。
## 外部知识库
{}
"""




