from custom.workflows.flow_hello import helloLLM_workflow
from custom.workflows.flow_chat import chat_workflow

from custom.workflows.flow_ny import ny_workflow
from custom.workflows.flow_yolov11det import detImage_workflow
from custom.workflows.flow_workreport import workreport_workflow
from custom.workflows.flow_papers import papers_flow
from custom.workflows.flow_novel import novel_workflow