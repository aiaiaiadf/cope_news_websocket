import os
import sys
sys.path.append(".")
import time
import json
import asyncio
import warnings
warnings.filterwarnings("ignore")
import datetime
from datetime import datetime as dt
from datetime import timezone as tz
from concurrent.futures import ThreadPoolExecutor

import redis
from pymongo import MongoClient
from collections import Counter

from custom.workflows.hot_news_flow import hot_news_flow
from mainbrainQA_core.core.state_base import MainGraphState
from mainbrainQA_core.common.llm_utils import str2dict
from mainbrainQA_core.common.utils import show_lg,show_er,show_wn_p,show_wn,show_lg_p,show_er_p,show_db_p,readConf,strptime,timepstr, writeJson



def set_redis_key_with_expiry(redis_client, key, value):
    """
    在Redis中设置带有到期日期的键值对。

    :param redis_client: Redis客户端实例
    :param key: 键名称
    :param value: 键的值
    :param expiry_date: start_time + day=1
    """
    # current_time = datetime.utcnow().replace(tzinfo=timezone.utc)
    current_time = dt.now()
    expiry_date = current_time.replace(hour=1,minute=0,second=0,microsecond=0) + datetime.timedelta(days=1)
    # 计算过期时间（秒）
    expiry_seconds = int((expiry_date - current_time).total_seconds())
    
    # 设置Redis键值对及过期时间
    redis_client.rpush(key, value, ex=expiry_seconds)


def setup_gpu(gpu_id=0):
    """配置 GPU 环境"""
    os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"  # 按物理顺序排序
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu_id)


async def async_graph_invoke_write(i,data,save_db,start_time):
    # #! graph
    setup_gpu(i%4)
    title = data["news"]["title"]
    content = data["news"]["content"]
    if len(content) > 2500:
        return data
    state = MainGraphState()
    # state.parameters.update({"news_title":title,"news_content":content})
    state.parameters.update({"news_title":title})
    out_state = await hot_news_flow().ainvoke(state)
    show_db_p(f">>> out_state   ",out_state)
    if out_state.latest_response.get("stance"):
        data.update({"stance":out_state.latest_response["stance"]})
        labels = data["label"]
        for label in labels.split():
            collent = save_db[label]
            collent.insert_one(data)
    else:
        show_wn_p(f"err-->  {out_state}")
    return data

def graph_invoke_write(i,data,save_db,start_time):
    return asyncio.run(async_graph_invoke_write(i,data,save_db,start_time))

def information_within_the_time_interval(collection,start_time,end_time) -> list:
    results = collection.find({
        "news.date": {
            "$gte": start_time,
            "$lte": end_time
        }
    }).sort("news.date", 1)
    return list(results)

def remove_duplicates(lst:list)->list:
    seen = set()
    unique_list = []
    for item in lst:
        _id = str(item["_id"]) 
        if _id not in seen:
            seen.add(_id)
            unique_list.append(item)
    return unique_list

# "2025-05-07T10:30:00Z"
def run():
    user_msg = readConf("configs/user.conf")
    mongo_msg = readConf("configs/hot_news_mongo.conf")
    redis_msg = readConf("configs/redis.conf")
    show_db_p(user_msg)
    show_db_p(mongo_msg)
    show_db_p(redis_msg)
    # if os.path.exists("configs/cursor_.txt"):
    #     with open("configs/cursor.txt") as rf:
    #         cursor = rf.readline().strip()
    #     start_time = strptime(cursor).replace(minute=0,second=0)
    # else:
    #     try:
    #         start_time = strptime(user_msg["start_tm"])
    #     except:
    #         show_wn("use now date")
    #         start_time = dt.now().replace(minute=0,second=0)
    try:
        start_time = strptime(user_msg["start_tm"])
    except:
        show_wn("use now date")
        start_time = strptime(timepstr(dt.now().replace(hour=0,minute=0)))
    end_time = start_time + datetime.timedelta(minutes=int(user_msg["interval"]))
    
    while True:
        # s1 = time.time()
        show_db_p(f"start_time:   {start_time}  end_time:   {end_time}")
       
        #^ 创建服务   避免某伦运行出错，挂掉
        redis_client = redis.Redis(host=redis_msg["redis_ip"], port=int(redis_msg["port"]), db=int(redis_msg["db"]))

        mongo_client = MongoClient(mongo_msg["mongodb_ip"]) 
        retrieve_db = mongo_client[mongo_msg["retrieve_table_name"]]
        save_db = mongo_client[mongo_msg["save_table_name"]]

        #^ 从mongo中获取时间区间内的数据
        retrieve_collection_names = retrieve_db.list_collection_names()
        show_db_p(f"retrieve_collection_names    {retrieve_collection_names}")
        tmp_lst = list()
        for collection_name in retrieve_collection_names:
            if collection_name in user_msg["not_keys"].split(","):
                continue
            else:
                # show_lg_p(f"collection_name  {collection_name}  \|/")
                retrieve_collection = retrieve_db[collection_name]
                results = information_within_the_time_interval(retrieve_collection,start_time,end_time)
                tmp_lst.extend(results)

        # show_lg_p(f"tmp_lst    {tmp_lst}")
        if len(tmp_lst)!=0:
            tmp_lst = remove_duplicates(tmp_lst)
            results = []
            with ThreadPoolExecutor(max_workers=int(user_msg["max_works"])) as executor:
                futures = []
                for i,data in enumerate(tmp_lst):
                    futures.append(executor.submit(graph_invoke_write,i,data,save_db,start_time))
                for future in futures:
                    r = future.result()
                    show_lg(r)
                    if r.get("stance"):
                        results.append(r)
            if len(results) ==0:
                continue
            
            for data in results:
                # data['dateScore'] = timepstr(data['dateScore'])
                data['news']['date'] = timepstr(data['news']['date'])
                data['_id'] = str(data['_id'])
                json_data = json.dumps(data)
                for label in data["label"].split():
                    set_redis_key_with_expiry(redis_client,label,json_data)
                    # redis_client.rpush(label,json_data)

   
        
        # 时间更新
        tmp_start_time = end_time 
        
        #~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        #! 当到了午夜1点，需要统计redis新闻数量
        if tmp_start_time == start_time.replace(hour=0,minute=0) + datetime.timedelta(days=1):
            hot_news_num_dct = dict()
            for collection_name in retrieve_collection_names:
                data_lst = redis_client.lrange(collection_name,0,-1)
                # tmp_num_dct = dict()
                # for data in data_lst:
                #     data = json.loads(data.decode('utf-8'))
                #     if data["stance"] in tmp_num_dct:
                #         tmp_num_dct[data["stance"]] +=1
                #     else:
                #         tmp_num_dct[data["stance"]] =1
                # hot_news_num_dct[collection_name] = tmp_num_dct
                tmp_num = 0
                for data in data_lst:
                    data = json.loads(data.decode('utf-8'))
                    tmp_num +=1
                hot_news_num_dct[collection_name] = tmp_num
            writeJson("share/hot_news_num.json",hot_news_num_dct)

        start_time = tmp_start_time
        end_time = start_time + datetime.timedelta(hours=1)

        #! 
        redis_client.close()
        mongo_client.close()
        if start_time > dt.now():
            sec = (end_time - dt.now).total_seconds()
            time.sleep(sec+120)  #^ 等待到未来的时间
            # with open("configs/cursor.txt",'w') as wf:
            #     wf.write(timepstr(dt.now()))
            # break
            # if int(user_msg["is_test"])>0:
            #     break
            # else:
            #     continue
            #     # during = int(user_msg["interval"])*60 - (time.time() - s1) + 5
            #     # show_db_p(f"during    {during}")
            #     # time.sleep(during)
        else:
            #^ 继续搞事情
            time.sleep(4)
        
    show_wn("done")


if __name__ == "__main__":    
    run()
