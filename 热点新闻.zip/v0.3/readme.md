# post接口说明

```bash
https://120.241.223.8:28088/news/hot_news
```
# 发送的结构体
```json
{
    "news_classify":新闻类别，与前面的相同
}
```



# 返回数据格式说明


```json
{
    "results":{
        "last_day_news_info":
        {
            "AI":
            {
                "num":6,

                "active":"1",
                "negative":"2",
                "neutrality":"4"
            },
            "BTC":
            {
                "active":"1",
                "negative":"2",
                "neutrality":"4"
            }
        },
        "active":"9",
        "negative":"12",
        "neutrality":"14",
        "flg":"0",
        "news":
        [
            {
                "_id": "90ce0eb26dc9a94d0b33d008",
                "label": "other",
                "news": {
                    "id": "90ce0eb26dc9a94d0b33d00",
                    "date": "2025-05-07_14-05-00",
                    "title": "Binance Alpha新增Polyhedra(ZKJ)",
                    "content": "PANews 5月7日消息，币安APP页面显示，Binance Alpha新增Polyhedra Network (ZKJ) 。",
                    "website": "panewslab",
                    "src": "https://www.panewslab.com/zh/sqarticledetails/v34cthds.html"
                },
                "next": "",
                "stance": "active"
            },
            {
                "_id": "90ce0eb26dc9a94d0b33d008",
                "label": "other",
                "news": {
                    "id": "90ce0eb26dc9a94d0b33d00",
                    "date": "2025-05-07_14-05-00",
                    "title": "Binance Alpha新增Polyhedra(ZKJ)",
                    "content": "PANews 5月7日消息，币安APP页面显示，Binance Alpha新增Polyhedra Network (ZKJ) 。",
                    "website": "panewslab",
                    "src": "https://www.panewslab.com/zh/sqarticledetails/v34cthds.html"
                },
                "next": "",
                "stance": "active"
            },

        ]
    }
}
```


## 格式说明

```json
{
    "results":{
        "last_day_news_info":   # 上一天的各种虚拟币的热点新闻数量
        {
            "AI":
            {
                "num":6,
            },
            "BTC":
            {
                "num":7,
            }
        },
        "active":"9",       # 此种虚拟币的积极新闻数量
        "negative":"12",    # 此种虚拟币的消极新闻数量
        "neutrality":"14",  # 此种虚拟币的中立新闻数量
        "flg":"0",          # 倾向 0-强烈买入 1-买入 2-中立 3-卖出 4-强烈卖出
        "news":             # 当天此种虚拟货币的所有新闻
        [                   # 注意"stance"关键字，其他的与前面的相同
            {
                "_id": "90ce0eb26dc9a94d0b33d008",
                "label": "other",
                "news": {
                    "id": "90ce0eb26dc9a94d0b33d00",
                    "date": "2025-05-07_14-05-00",
                    "title": "Binance Alpha新增Polyhedra(ZKJ)",
                    "content": "PANews 5月7日消息，币安APP页面显示，Binance Alpha新增Polyhedra Network (ZKJ) 。",
                    "website": "panewslab",
                    "src": "https://www.panewslab.com/zh/sqarticledetails/v34cthds.html"
                },
                "next": "",
                "stance": "active"   # 新闻倾向态度   active  negative  neutrality
            },
            {
                "_id": "90ce0eb26dc9a94d0b33d008",
                "label": "other",
                "news": {
                    "id": "90ce0eb26dc9a94d0b33d00",
                    "date": "2025-05-07_14-05-00",
                    "title": "Binance Alpha新增Polyhedra(ZKJ)",
                    "content": "PANews 5月7日消息，币安APP页面显示，Binance Alpha新增Polyhedra Network (ZKJ) 。",
                    "website": "panewslab",
                    "src": "https://www.panewslab.com/zh/sqarticledetails/v34cthds.html"
                },
                "next": "",
                "stance": "active"
            },

        ]
    }
}
```