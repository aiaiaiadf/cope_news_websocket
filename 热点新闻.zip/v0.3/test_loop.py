# import asyncio
# from concurrent.futures import ThreadPoolExecutor

# import operator
# from typing import Annotated, Any
# from typing_extensions import TypedDict
# from langgraph.graph import StateGraph, START, END
# class State(TypedDict):
#     aggregate: Annotated[list, operator.add]
# class ReturnNodeValue:
#     def __init__(self, node_secret: str):
#         self._value = node_secret
#     def __call__(self, state: State) -> Any:
#         print(f"Adding {self._value} to {state['aggregate']}")
#         return {"aggregate": [self._value]}
# async def langgraph_inference(graph_data):
#     builder = StateGraph(State)
#     builder.add_node("a", ReturnNodeValue("I'm A"))
#     builder.add_edge(START, "a")
#     builder.add_node("b", ReturnNodeValue("I'm B"))
#     builder.add_node("c", ReturnNodeValue("I'm C"))
#     builder.add_node("d", ReturnNodeValue("I'm D"))
#     builder.add_edge("a", "b")
#     builder.add_edge("a", "c")
#     builder.add_edge("b", "d")
#     builder.add_edge("c", "d")
#     builder.add_edge("d", END)
#     graph = builder.compile()
#     out = await graph.ainvoke(graph_data)
#     return out


# # 异步包装器函数
# async def async_langgraph_task(executor, graph_data):
#     loop = asyncio.get_event_loop()
#     # 将同步函数提交到线程池并封装为异步任务
#     result = await loop.run_in_executor(executor, langgraph_inference, graph_data)
#     return result

# async def main():
#     # 创建最大4线程的线程池
#     with ThreadPoolExecutor(max_workers=4) as executor:
#         # 模拟要处理的图数据列表
#         graph_data_list = [f"graph_{i}" for i in range(8)]
        
#         # 创建异步任务列表
#         tasks = [
#             async_langgraph_task(executor, data) 
#             for data in graph_data_list
#         ]
        
#         # 并发执行所有任务并等待结果
#         results = await asyncio.gather(*tasks)
        
#         # 打印所有结果
#         for result in results:
#             print(result)

# if __name__ == "__main__":
#     asyncio.run(main())
import operator
import asyncio
from concurrent.futures import ThreadPoolExecutor
from typing import Annotated, Any,Dict
from typing_extensions import TypedDict
from langgraph.graph import StateGraph, START, END
from pydantic import BaseModel, ConfigDict,Field
class State(TypedDict):
    aggregate: Annotated[list, operator.add]
    thread_id: str= Field(default_factory=str)
    # configurable:Dict[str, Any]= Field(default_factory=dict)
class ReturnNodeValue:
    def __init__(self, node_secret: str):
        self._value = node_secret

    def __call__(self, state: State) -> Any:
        print(f"Adding {self._value} to {state['aggregate']}   {state['thread_id']}")
        return {"aggregate": [self._value]}

async def langgraph_inference(graph_data):
    builder = StateGraph(State)
    builder.add_node("a", ReturnNodeValue("I'm A"))
    builder.add_edge(START, "a")
    builder.add_node("b", ReturnNodeValue("I'm B"))
    builder.add_node("c", ReturnNodeValue("I'm C"))
    builder.add_node("d", ReturnNodeValue("I'm D"))
    builder.add_edge("a", "b")
    builder.add_edge("a", "c")
    builder.add_edge("b", "d")
    builder.add_edge("c", "d")
    builder.add_edge("d", END)
    graph = builder.compile()
    out = await graph.ainvoke(graph_data)
    return out

# 同步包装器函数
def run_inference_sync(graph_data):
    return asyncio.run(langgraph_inference(graph_data))

# 创建线程池（最大4线程）
executor = ThreadPoolExecutor(max_workers=4)

# 示例用法：提交多个任务到线程池
if __name__ == "__main__":
    graph_data_samples = [{"aggregate": [],"thread_id":"input1"},
                          {"aggregate": [], "thread_id":"input2"},
                          {"aggregate": [], "thread_id":"input3"},
                          {"aggregate": [], "thread_id":"input4"},
                          {"aggregate": [], "thread_id":"input5"},
                          {"aggregate": [], "thread_id":"input6"},
                          {"aggregate": [], "thread_id":"input7"}]
    futures = [executor.submit(run_inference_sync, data) for data in graph_data_samples]
    
    # 获取并打印结果
    for future in futures:
        print("res->   ",future.result())
